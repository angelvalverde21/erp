<footer class="main-footer">
    <strong>Copyright &copy; 2014-2021 <a href="https://server.com.pe">ARA</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.2.0
    </div>
</footer><?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/components/footer.blade.php ENDPATH**/ ?>