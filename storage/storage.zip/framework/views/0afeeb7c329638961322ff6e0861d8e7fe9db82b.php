<div>
    
    <div class="logo">
        <img src="<?php echo e(Storage::url('logo.png')); ?>" alt="">
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/home-public.blade.php ENDPATH**/ ?>