<div>

    <style>
        .input-group-text{
            padding: 0 5px 0 10px !important;
            background-color: #fff !important;
        }

        .form-control{
            border-left: 0 !important;
            padding-left: 5px !important; 
        }
    </style>

    <div class="row">

        

        

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css">

        <div class="mb-5 p-4 bg-white shadow-sm">
            
            <div id="stepper1" class="bs-stepper linear">
                <div class="bs-stepper-header" role="tablist">


                    <?php if($order->shipping_cost_to_carrier > 0): ?>
                        <div class="step active" data-target="#test-l-1">
                    <?php else: ?>
                        <div class="step" data-target="#test-l-1">
                    <?php endif; ?>
                            <button type="button" class="step-trigger" role="tab" id="stepper1trigger1"
                                aria-controls="test-l-1" aria-selected="true">
                                <span class="bs-stepper-circle"><li class="fa-solid fa-user"></li></span>
                                <span class="bs-stepper-label">Envio</span>
                            </button>
                        </div>

                    <div class="bs-stepper-line"></div>

                    <?php if($order->shipping_cost_carrier > 0): ?>
                        <div class="step active" data-target="#test-l-2">
                    <?php else: ?>
                        <div class="step" data-target="#test-l-2">
                    <?php endif; ?>

                        <button type="button" class="step-trigger" role="tab" id="stepper1trigger2"
                            aria-controls="test-l-2" aria-selected="false">
                            <span class="bs-stepper-circle"><i class="fa-solid fa-motorcycle"></i></span>
                            <span class="bs-stepper-label">Translado</span>
                        </button>
                    </div>

                    <div class="bs-stepper-line"></div>

                    <?php if($order->shipping_cost_buyer > 0): ?>
                        <div class="step active" data-target="#test-l-3">
                    <?php else: ?>
                        <div class="step" data-target="#test-l-3">
                    <?php endif; ?>

                        <button type="button" class="step-trigger" role="tab" id="stepper1trigger3"
                            aria-controls="test-l-3" aria-selected="false">
                            <span class="bs-stepper-circle"><i class="fa-solid fa-truck"></i></span>
                            <span class="bs-stepper-label">Agencia</span>
                        </button>
                    </div>
                </div>
            </div>

            <div id="stepper2" class="bs-stepper linear">
                <div class="bs-stepper-header" role="tablist">
                    <div class="step active" data-target="#test-l-1">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-number','data' => ['wirevalue' => 'order.shipping_cost_buyer','texticon' => 'S/.','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'order.shipping_cost_buyer','texticon' => 'S/.','error' => 'Este campo es requerido']); ?>
                            0.00
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <div class="bs-stepper-line"></div>
                    <div class="step" data-target="#test-l-2">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-number','data' => ['wirevalue' => 'order.shipping_cost_carrier','texticon' => 'S/.','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'order.shipping_cost_carrier','texticon' => 'S/.','error' => 'Este campo es requerido']); ?>
                            0.00
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <div class="bs-stepper-line"></div>
                    <div class="step" data-target="#test-l-3">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-number','data' => ['wirevalue' => 'order.shipping_cost_to_carrier','texticon' => 'S/.','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'order.shipping_cost_to_carrier','texticon' => 'S/.','error' => 'Este campo es requerido']); ?>
                            0.00
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        

    </div>

    <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled" wire.target="save"
        wire:click.prevent="saveOrder()" class="btn btn-success ml-auto"><i class="fa-solid fa-floppy-disk mr-1"></i>
        Guardar</button>

    <div class="spinner-border" wire:loading.inline-flex wire:target="saveOrder" role="status">
        <span class="sr-only">Loading...</span>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/modal-carrier-details.blade.php ENDPATH**/ ?>