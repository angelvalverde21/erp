<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['userid', 'field', 'wirekey', 'filename', 'iddrop']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['userid', 'field', 'wirekey', 'filename', 'iddrop']); ?>
<?php foreach (array_filter((['userid', 'field', 'wirekey', 'filename', 'iddrop']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<style>
    .dropzone{
        border: 1px dashed #ccc !important;
    }
</style>

<div class="card mt-3" style="width: 100%">
    <div class="card-header"><?php echo e($slot); ?></div>
    <div class="card-body">

        
        <div wire:ignore class="" wire:key="<?php echo e($wirekey); ?>">

            <form method="POST" action="<?php echo e(route('user.profile.upload', [ 'user'=> $userid, 'field'=> $field ])); ?>" class="dropzone"
                id="<?php echo e($iddrop); ?>">
            </form>
        </div>

        <?php if($filename): ?>
            <div class="text-center mt-3" style="100%">
                <img style="width: 150px;" src="<?php echo e(Storage::url($filename)); ?>" alt="">
            </div>
            
        <?php endif; ?>

        
        
    </div>
    
    <?php if($filename): ?>
        <div class="card-footer">
            <a href="#" wire:click.prevent="$emit('uploadPhotoJs','<?php echo e($userid); ?>', '<?php echo e($field); ?>')"
                class="btn btn-danger d-block">Borrar</a>
        </div>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/user/card-upload-user.blade.php ENDPATH**/ ?>