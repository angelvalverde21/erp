<div>
    

    <style>
        .dz-preview {
            margin: 10px !important
        }
    </style>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.locations.create-location', ['album' => $album, 'reloadUrl' => true], 'location-album-' . $album->id)->html();
} elseif ($_instance->childHasBeenRendered('l1307041692-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1307041692-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1307041692-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1307041692-0');
} else {
    $response = \Livewire\Livewire::mount('components.locations.create-location', ['album' => $album, 'reloadUrl' => true], 'location-album-' . $album->id);
    $html = $response->html();
    $_instance->logRenderedChild('l1307041692-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="accordion" id="accordionAlbum">

            

            <?php if($album->locations->count() > 0): ?>

                <?php $__currentLoopData = $album->locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accordion-item','data' => ['id' => 'item-album-location-'.e($location->pivot->id).'','show' => ''.e($loop->first).'','label' => ''.e($location->name).' ('.e(albumLocation($album->id, $location->id)->images->count()).')','accordionParentId' => 'accordionAlbum']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('accordion-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'item-album-location-'.e($location->pivot->id).'','show' => ''.e($loop->first).'','label' => ''.e($location->name).' ('.e(albumLocation($album->id, $location->id)->images->count()).')','accordion_parent_id' => 'accordionAlbum']); ?>


                        <div class="row pb-3" wire:ignore>

                            <div class="mt-3 album d-flex flex-wrap justify-content-around">

                                <div class="card text-center" style="width: 340px">
                                    <form method="POST" wire:ignore.self
                                        action="<?php echo e(route('manage.albums.upload', [$store->nickname, $album, $location])); ?>"
                                        class="dropzone d-flex flex-wrap justify-content-around p-3"
                                        id="my-awesome-dropzone-albums">
                                    </form>

                                </div>

                                <?php $__currentLoopData = albumLocation($album->id, $location->id)->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    

                                    <div class="card text-center" style="width: 340px">

                                        <a href="<?php echo e(Storage::disk('spaces')->url($photo->medium)); ?>"
                                            data-fancybox="gallery" data-caption="<?php echo e($photo->name); ?>">

                                            <img loading="lazy" src="<?php echo e(Storage::disk('spaces')->url($photo->medium)); ?>"
                                                class="card-img-top" height="" alt="...">
                                        </a>

                                        <span><?php echo e($photo->name); ?></span>

                                        <div class="controles d-flex justify-content-between p-3">

                                            

                                            <a target="_blank" href="<?php echo e(Storage::disk('spaces')->url($photo->large)); ?>"
                                                class="btn btn-success"><i class="fa-solid fa-download me-1"></i>
                                                Descargar</a>


                                            <?php if($user->hasRole('admin')): ?>
                                                <button type="button" wire:loading.attr="disabled"
                                                    wire.target="delete-<?php echo e($photo->id); ?>"
                                                    wire:click="delete('<?php echo e($photo->large); ?>')" class="btn btn-danger">
                                                    <i class="fa-solid fa-trash me-1"></i>Borrar</button>

                                                <div wire:loading wire:target="delete-<?php echo e($photo->id); ?>"
                                                    class="spinner-border" role="status">
                                                    <span class="sr-only">Espere...</span>
                                                </div>
                                            <?php endif; ?>

                                        </div>

                                        
                                    </div>

                                    

                                    

                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                No hay locaciones para mostrar, antes de subir las fotos cree una locacion
            <?php endif; ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>

<style>
    .dropzone {
        width: 100% !important;
        height: 100% !important;
    }

    .dz-default{
        display: flex !important;
        align-items: center!important;
    }
</style>

<?php $__env->startPush('script'); ?>

    <script>
        Dropzone.options.myAwesomeDropzoneAlbums = {
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            dictDefaultMessage: "<div class='add-photos'>Agregar + fotos al album </div> <i class=\"fas fa-camera mt-5\" style=\"font-size: 18pt;\"></i>",
            acceptedFiles: "image/*",
            paramName: "file", // The name that will be used to transfer the file
            maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
            complete: function(file) {
                this.removeFile(file);
            },
            queuecomplete: function() {
                Livewire.emit('render');
                //OJO REFRESCAMOS LA PAGINA PARA QUE DROPZONE VUELVA A LEER LOS NUEVOS FORMULARIOS AGREGADOS DINAMICAMENTE
                window.location.reload()
            },
            accept: function(file, done) {
                if (file.name == "justinbieber.jpg") {
                    done("Naha, you don't.");
                } else {
                    done();
                }
            }
        };
    </script>

    <script>
        $(document).ready(function() {

            Livewire.on('reloadUrl', function() {
                // Obtener el elemento Dropzone

                window.location.reload()
            });

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product/albums/edit-album.blade.php ENDPATH**/ ?>