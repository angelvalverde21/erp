<div>

    <ul class="list-group mb-3">
        

        <li class="list-group-item d-flex justify-content-between align-items-center">
            <span>
                <strong>Fecha de entrega:</strong> 
                <?php if($order->MessagenCalendar != ''): ?>
                    <?php echo e($order->delivery_date); ?> (<?php echo e($order->MessagenCalendar); ?>)
                <?php else: ?>
                    <?php echo e($order->delivery_date); ?>

                <?php endif; ?>
            </span>
            <div class="controls">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.button-open-modal','data' => ['target' => '#modal-date-edit-details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#modal-date-edit-details']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </li>


        <li class="list-group-item d-flex justify-content-between">
            <span>Hora:</span>
            <div class="data">
                De <?php echo e($order->delivery_time_start); ?> Hasta <?php echo e($order->delivery_time_end); ?>

            </div>
        </li>

        <?php if($order->observations_time != ''): ?>
            <li class="list-group-item d-flex justify-content-between">
                <span>Observaciones:</span>
                <div class="data text-end">
                    <?php echo e($order->observations_time); ?>

                </div>
            </li>
        <?php endif; ?>



    </ul>


    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Fecha de entrega','id' => 'modal-date-edit-details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Fecha de entrega','id' => 'modal-date-edit-details']); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.modal-date-details', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('modal-date-edit-details-' . $order->id)) {
    $componentId = $_instance->getRenderedChildComponentId('modal-date-edit-details-' . $order->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('modal-date-edit-details-' . $order->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('modal-date-edit-details-' . $order->id);
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.modal-date-details', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('modal-date-edit-details-' . $order->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

         <?php $__env->slot('footer', null, []); ?> 

         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/card-date-details.blade.php ENDPATH**/ ?>