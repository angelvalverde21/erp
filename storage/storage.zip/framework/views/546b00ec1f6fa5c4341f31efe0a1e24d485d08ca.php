<div>
    
    <div>
        <div class="card">

            <div class="card-header py-3">
                <div class="header-content d-flex justify-content-between">
                    <h5>Precios por lote</h5>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.button-open-modal','data' => ['class' => 'primary float-end','text' => 'Agregar Precio','target' => '#editCarrierOrderDetails']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'primary float-end','text' => 'Agregar Precio','target' => '#editCarrierOrderDetails']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>


            <div class="card-body">

                <table class="table table table-striped">

                    <thead>
                        <tr>
                            
                            <th class="text-center">Qty</th>
                            <th class="text-center">x</th>
                            <th class="text-center">Precio</th>
                            <th class="text-center">=</th>
                            <th class="text-center">Total</th>
                            <th class="text-center">Creado</th>
                            <th class="text-center">Delete</th>
                        </tr>
                    </thead>

                    <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td class="text-center"><?php echo e($price->quantity); ?></td>
                            <td class="text-center">x</td>
                            <td class="text-center">S/. <?php echo e($price->value); ?></td>
                            <td class="text-center">=</td>
                            <td class="text-center">S/. <?php echo e($price->value_total); ?></td>
                            <td class="text-center"><?php echo e($price->created_at); ?></td>
                            <td class="text-center">
                                <a href="#" wire:click.prevent="deletePrice(<?php echo e($price->id); ?>)" class="btn btn-danger"><i
                                    class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

            </div>

        </div>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Precio de venta','id' => 'editCarrierOrderDetails','size' => 'modal-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Precio de venta','id' => 'editCarrierOrderDetails','size' => 'modal-lg']); ?>


            <form action="">

                <div class="row">

                    <div class="col-4 col-lg-4">
                        <label for="">Cantidad</label>
                        <input class="form-control" placeholder="0" type="number" id="" step="1" wire:model.debounce.500ms="quantity">
                    </div>

                    <div class="col-4 col-lg-4">
                        <label for="">Precio Unitario</label>
                        <input class="form-control" placeholder="0.00" type="number" id="" step="0.01" wire:model.debounce.500ms="price">
                    </div>

                    <div class="col-4 col-lg-4">
                        <label for="">Total Oferta</label>
                        <input class="form-control" placeholder="0.00" type="number" id="" step="0.01" wire:model.debounce.500ms="price_total">
                    </div>

                </div>

            </form>

             <?php $__env->slot('footer', null, []); ?> 
                <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled" wire.target="save"
                wire:click.prevent="createPrice()" class="btn btn-success ml-auto"><i class="fa-solid fa-floppy-disk mr-1"></i>
                Guardar</button>
             <?php $__env->endSlot(); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    </div>



</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/prices/show-prices.blade.php ENDPATH**/ ?>