<div>
    


    <div class="head-color d-flex justify-content-between">

        <h6><i class="fa-solid fa-cart-flatbed mr-2"></i>( <?php echo e($product->quantity); ?> ) Productos en almacen</h6>

        
    
        
    
        <h6><?php echo e($colors->count()); ?> disenos disponibles</h6>
    </div>

    <?php if($colors->count()>0): ?>

        <div class="input-group mb-3">
            <input type="text" class="form-control buscar_table" placeholder="Buscar Color">
            <div class="input-group-append">
                <span class="input-group-text">
                    <li class="material-icons">search</li>
                </span>
            </div>
        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-striped dataTable dtr-inline">

                <thead>
                    <tr>
                        <td class="text-center">Codigo</td>
                        <td class="text-center">Agregar Stock</td>
                        <td class="text-center">Colores</td>
                        <td class="text-center">Variantes</td>
                        <td class="text-center">Eliminar</td>
                    </tr>
                </thead>

                <tbody>
                    

                    <tr class="text-center">
                        <td class="text-center"></td>
                        <td class="text-center"></td>
                        <td class="text-center">
                            <div class="row p-3" wire:ignore>

                                <form method="POST" action="<?php echo e(route('manage.products.upload.colors', [$store->nickname, $product])); ?>"
                                    class="dropzone" id="my-awesome-dropzone-colors">
                                </form>
                        
                            </div>
                        </td>
                        <td class="text-center"></td>
                        <td class="text-center"></td>
                    </tr>

                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <tr class="text-center">
                            <td class="text-center"><?php echo e($color->id); ?></td>
                            <td>
                                
                                <button class="btn btn-success" style="width: 115px;" data-toggle="modal"
                                    data-target="#editarStock-<?php echo e($color->id); ?>" type="button" class="d-flex justify-content-between align-items-center"><i
                                        class="fa-solid fa-barcode me-1"></i><span>Editar Stock</span></button>

                                        <table class="table mt-3">

                                            <?php $__currentLoopData = $color->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($size->name); ?></td>
                                                <td><?php echo e($size->pivot->quantity); ?></td>
                                            </tr>      
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                            </td>

                            <?php if($color->image): ?>
                                <td>
                                    

                                    <a href="<?php echo e(Storage::url($color->image->name)); ?>" data-lightbox="colors"
                                        data-title="Stock: <?php echo e($color->quantity); ?>">
                                        <img loading="lazy" src="<?php echo e(Storage::url($color->image->name)); ?>" alt="" width="100px"
                                            height="100%">
                                    </a>

                                    <div>(<?php echo e($color->quantity); ?>)</div>

                                    <?php if($color->label != ''): ?>
                                        <div>(<?php echo e($color->label); ?>)</div>
                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.products.edit-product.colors.edit-color-modal', ['color' => $color, 'store' => $store])->html();
} elseif ($_instance->childHasBeenRendered('edit-color-' . $color->id)) {
    $componentId = $_instance->getRenderedChildComponentId('edit-color-' . $color->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('edit-color-' . $color->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('edit-color-' . $color->id);
} else {
    $response = \Livewire\Livewire::mount('manage.products.edit-product.colors.edit-color-modal', ['color' => $color, 'store' => $store]);
    $html = $response->html();
    $_instance->logRenderedChild('edit-color-' . $color->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                    

                                </td>
                            <?php else: ?>
                                <td>
                                    No hay imagen
                                </td>

                                <td>

                                </td>
                            <?php endif; ?>

                            

                            <td wire:key="color-<?php echo e($color->id); ?>" class="text-center">
                                <a class="btn-color" href="#"
                                    wire:click.prevent="deleteColor(<?php echo e($color->id); ?>)" wire:loading.attr="disabled"
                                    wire:target="deleteColor(<?php echo e($color->id); ?>)"><i
                                        class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="contenedor">

            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Editar Stock','id' => 'editarStock-'.e($color->id).'','size' => 'modal-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Editar Stock','id' => 'editarStock-'.e($color->id).'','size' => 'modal-lg']); ?>

                    <div class="row text-center">
                        <div class="col-lg-4 col-12">
                            <?php if($color->image): ?>
                                <img src="<?php echo e(Storage::url($color->image->name)); ?>" alt="" width="100%"
                                    height="100%">
                            <?php endif; ?>
                        </div>

                        <div class="col-lg-8 col-12">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.products.edit-product.stock-color-size', ['color' => $color])->html();
} elseif ($_instance->childHasBeenRendered('stock-color-size-' . $color->id)) {
    $componentId = $_instance->getRenderedChildComponentId('stock-color-size-' . $color->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('stock-color-size-' . $color->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('stock-color-size-' . $color->id);
} else {
    $response = \Livewire\Livewire::mount('manage.products.edit-product.stock-color-size', ['color' => $color]);
    $html = $response->html();
    $_instance->logRenderedChild('stock-color-size-' . $color->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    <?php else: ?>

        <div class="row p-3" wire:ignore>

            <form method="POST" action="<?php echo e(route('manage.products.upload.colors', [$store->nickname, $product])); ?>"
                class="dropzone" id="my-awesome-dropzone-colors">
            </form>
    
        </div>

    <?php endif; ?>


    

</div>

<?php $__env->startPush('script'); ?>
    <script>
        Dropzone.options.myAwesomeDropzoneColors = {
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            dictDefaultMessage: "<div>Agregar colores</div> <i class=\"fas fa-camera mt-5\" style=\"font-size: 18pt;\"></i>",
            acceptedFiles: "image/*",
            paramName: "file", // The name that will be used to transfer the file
            maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
            complete: function(file) {
                this.removeFile(file);
            },
            queuecomplete: function() {
                Livewire.emit('render');
                //OJO REFRESCAMOS LA PAGINA PARA QUE DROPZONE VUELVA A LEER LOS NUEVOS FORMULARIOS AGREGADOS DINAMICAMENTE
                window.location.reload()
            },
            accept: function(file, done) {
                if (file.name == "justinbieber.jpg") {
                    done("Naha, you don't.");
                } else {
                    done();
                }
            }
        };
    </script>

<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product/colors.blade.php ENDPATH**/ ?>