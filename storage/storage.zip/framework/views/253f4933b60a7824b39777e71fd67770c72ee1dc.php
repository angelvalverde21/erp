<div>
    

    

        <div class="card">

            <div class="card-header py-3">
                <a href="#" wire:click.prevent="createOrder()" class="btn btn-success">Crear Order</a>
            </div>

            <div class="card-body">

                <?php echo $__env->make('livewire.manage.orders._show-orders-table', ['orders' => $orders], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/customers/show-orders-customers.blade.php ENDPATH**/ ?>