<div>
    <div class="card">

        <div class="card-header">

            <div class="d-flex justify-content-between align-items-center">
                <div class="title d-flex align-items-center">
                    <i class="fa-solid fa-truck mr-2"></i> <span>Enviar por:</span>
                </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.button-open-modal','data' => ['target' => '#editCarrierOrder']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#editCarrierOrder']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
        
        <div class="card-body py-3">

            <style>
                .carrier{
                    position: relative;
                }

                .logo-carrier{
                    position: absolute;
                    right: 10px;
                    bottom: 0px;
                    z-index: 100;
                    width: 25%
                }
            </style>

            <div class="carrier">
                <div class="details">
                    <?php if($order->carrier_address): ?>
                    <li><h4><?php echo e($order->carrier_address->title); ?></h4></li>
                    <li><?php echo e($order->carrier_address->name); ?></li>
                    <li><?php echo e($order->carrier_address->phone); ?></li>
                    <li><?php echo e($order->carrier_address->primary); ?></li>
                    <li><?php echo e($order->carrier_address->secondary); ?></li>
                    <li><?php echo e($order->carrier_address->district->name); ?> -
                        <?php echo e($order->carrier_address->district->province->name); ?> -
                        <?php echo e($order->carrier_address->district->province->department->name); ?></li>
                    <?php else: ?>
                        No hay courier, debe seleccionar uno
                    <?php endif; ?>
                </div>
                <div class="logo-carrier">
                    <img src="<?php echo e($order->carrier_address->user->getOption('logo_profile')); ?>" width="100%">
                </div>
            </div>



        </div>

    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'editar transportista','id' => 'editCarrierOrder','size' => 'modal-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'editar transportista','id' => 'editCarrierOrder','size' => 'modal-lg']); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.carriers.show-carrier-all', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('show-carrier-all-' . $order->id)) {
    $componentId = $_instance->getRenderedChildComponentId('show-carrier-all-' . $order->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('show-carrier-all-' . $order->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('show-carrier-all-' . $order->id);
} else {
    $response = \Livewire\Livewire::mount('components.carriers.show-carrier-all', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('show-carrier-all-' . $order->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

         <?php $__env->slot('footer', null, []); ?> 

         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/card-carrier-details.blade.php ENDPATH**/ ?>