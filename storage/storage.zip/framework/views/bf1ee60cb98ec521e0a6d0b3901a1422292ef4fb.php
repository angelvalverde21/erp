<div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex">

                <select class="form-control custom-select mb-3 mr-2">
                    <option value="2">Escoger Locacion</option>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <a href="#" class="btn btn-secondary mb-3" data-toggle="modal" data-target="#newlocation">Nuevo</a>
            </div>
        </div>
        <!--/span-->

        <!--/span-->
    </div>
    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Agregar nueva locacion','id' => 'newlocation','size' => 'modal-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar nueva locacion','id' => 'newlocation','size' => 'modal-lg']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.locations.create-location')->html();
} elseif ($_instance->childHasBeenRendered('l2675888980-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2675888980-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2675888980-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2675888980-0');
} else {
    $response = \Livewire\Livewire::mount('components.locations.create-location');
    $html = $response->html();
    $_instance->logRenderedChild('l2675888980-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/locations/show-locations.blade.php ENDPATH**/ ?>