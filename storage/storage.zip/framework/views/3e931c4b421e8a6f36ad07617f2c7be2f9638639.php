<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <?php if(isset($title)): ?>
        <title><?php echo e($title); ?> <?php echo e(config('app.name', 'Laravel')); ?></title>
    <?php else: ?>
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <?php endif; ?>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    

    

    <script src="https://cdn.ckeditor.com/ckeditor5/38.0.1/classic/ckeditor.js"></script>

    

    <style>
        ul {
            margin: 0 !important;
            padding: 0 !important;
        }

        .main-sidebar,
        .sidebar-dark-primary {
            background-color: #484F56 !important;
        }

        .form-control-sidebar {
            background-color: #ffffff !important;
        }
    </style>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/current.js')); ?>"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    

    <style>
        .dropzone {
            border: 1.5px dashed #ccc !important;
            padding: 0 !important;
            min-height: 75px !important;
            width: 100%;
        }

        .dropzone .dz-preview {
            margin: 0px !important;
        }

        .dropzone .dz-message {
            margin: 0;
        }

        .card {
            border: 1px !important;
        }

        .dz-remove {
            margin: 2px;
            text-decoration: none;
        }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.2/min/dropzone.min.js"
        integrity="sha512-VQQXLthlZQO00P+uEu4mJ4G4OAgqTtKG1hri56kQY1DtdLeIqhKUp9W/lllDDu3uN3SnUNawpW7lBda8+dSi7w=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.2/dropzone.min.css"
        integrity="sha512-jU/7UFiaW5UBGODEopEqnbIAHOI8fO6T99m7Tsmqs2gkdujByJfkCbbfPSN4Wlqlb9TGnsuC0YgUgWkRBK7B9A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />


    

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/fontawesome-free/css/all.min.css')); ?>">

    <?php echo $__env->yieldPushContent('script-header'); ?>

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style_custom.css')); ?>">
    <!-- overlayScrollbars -->


    <!-- Tempusdominus Bootstrap 4 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">


    

    <link rel="stylesheet" href="<?php echo e(asset('lightbox2/dist/css/lightbox.min.css')); ?>">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css" />
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>

    

</head>

<body class="hold-transition sidebar-mini layout-fixed">

    <style>
        .has-danger {
            color: red;
        }

        body {
            font-size: 10pt;
        }

        .btn {
            font-size: 10pt !important;
        }

        li {
            list-style: none;
        }
    </style>

    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__shake" src="<?php echo e(asset('admin-lte/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTELogo"
                height="60" width="60">
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.components.header')->html();
} elseif ($_instance->childHasBeenRendered('7cxgMlx')) {
    $componentId = $_instance->getRenderedChildComponentId('7cxgMlx');
    $componentTag = $_instance->getRenderedChildComponentTagName('7cxgMlx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7cxgMlx');
} else {
    $response = \Livewire\Livewire::mount('manage.components.header');
    $html = $response->html();
    $_instance->logRenderedChild('7cxgMlx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.components.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('ids9iJU')) {
    $componentId = $_instance->getRenderedChildComponentId('ids9iJU');
    $componentTag = $_instance->getRenderedChildComponentTagName('ids9iJU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ids9iJU');
} else {
    $response = \Livewire\Livewire::mount('manage.components.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('ids9iJU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->

            <?php echo e($slot); ?>


        </div>
        <!-- /.content-wrapper -->

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.components.footer')->html();
} elseif ($_instance->childHasBeenRendered('pdfaKZa')) {
    $componentId = $_instance->getRenderedChildComponentId('pdfaKZa');
    $componentTag = $_instance->getRenderedChildComponentTagName('pdfaKZa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pdfaKZa');
} else {
    $response = \Livewire\Livewire::mount('manage.components.footer');
    $html = $response->html();
    $_instance->logRenderedChild('pdfaKZa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('admin-lte/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('admin-lte/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- ChartJS -->

    <?php echo $__env->yieldPushContent('script-footer'); ?>

    <!-- AdminLTE App -->

    <script src="<?php echo e(asset('admin-lte/dist/js/adminlte.js')); ?>"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    

    

    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>
        $(document).ready(function() {

            Livewire.on('creado', function() {

                // $('.modal').modal('hidden');

                Swal.fire(
                    'Creado!',
                    'Hemos creado el registro',
                    'success'
                ).then(function() {
                    //$(".modal-backdrop").hide();
                    // //$(".modal").hide();
                    // $('.modal').removeClass('show');
                    // $('body').removeClass('modal-open');
                    // $('.modal').hide();
                    // $('body').remove('modal-backdrop');

                    // $(".modal").each(function() {
                    //     $(this).toggle();
                    // });
                    console.log('Creado: se ha pulsado ok en sweetalert2');
                });

            })

            Livewire.on('Error', function() {

                // $('.modal').modal('hidden');

                Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Ha ocurrido un error interno',
                    }
                    // footer: '<a href="">Why do I have this issue?</a>'
                ).then(function() {
                    //$(".modal-backdrop").hide();
                    // //$(".modal").hide();
                    // $('.modal').removeClass('show');
                    // $('body').removeClass('modal-open');
                    // $('.modal').hide();
                    // $('body').remove('modal-backdrop');

                    // $(".modal").each(function() {
                    //     $(this).toggle();
                    // });
                    console.log('Creado: se ha pulsado ok en sweetalert2')
                });

            })
        });
    </script>

    <script>
        window.addEventListener('cerrar-modal', event => {

            // $(".modal").each(function() {
            //     $(this).hide();
            // });

            $(event.detail.modalID).modal('hide');


            console.log('el modal que vamos a cerrar es: ' + event.detail.modalID);
        })
    </script>

    <script>
        Livewire.on('actualizado', function() {
            Swal.fire(
                'Actualizado!',
                'Se ha guardado los datos',
                'success'
            )
        });
    </script>

    <script>
        Livewire.on('eliminado', function() {
            Swal.fire(
                'Borrado!',
                'Se ha borrado el registro',
                'success'
            )
        });
    </script>

    <script>
        Livewire.on('address-selected', function() {
            Swal.fire(
                'Seleccionado',
                'Se ha establecido la direccion por defecto',
                'success'
            )
        });
    </script>


    <script>
        Livewire.on('vacio', function() {
            Swal.fire({
                    icon: 'info',
                    title: 'Error',
                    text: 'Por favor complete los campos',
                }

            )
        });
    </script>

    
<script>
    Livewire.on('carpeta_exists', function() {
        Swal.fire({
                icon: 'info',
                title: 'Error',
                text: 'La carpeta ya existe',
            }

        )
    });
</script>

    <?php echo \Livewire\Livewire::styles(); ?>



    

    <script src="<?php echo e(asset('lightbox2/dist/js/lightbox-plus-jquery.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script'); ?>

    <script>
        $(".buscar_table").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $(".table tbody tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                //console.log($(this).text().toLowerCase().indexOf(value));
            });
        });
    </script>




    <!-- Scripts JavaScript -->

    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Coloca aquí tu código para inicializar FancyBox
            Fancybox.bind("[data-fancybox]", {
                // Configuración de FancyBox
                Images: {
                    initialSize: "fit", 
                },

                // Thumbs: false, // este atributo no funciona
                // showOnStart: false, este si funciona y se usa dentro de thumbs

                Thumbs: {
                    type: "classic",
                    showOnStart: true,
                },
                
            });
        });
    </script>

    

    

    

    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/layouts/manage.blade.php ENDPATH**/ ?>