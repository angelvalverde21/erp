<div>
    

    <style>
        .albumes {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 1rem;


        }

        .albumes .card {}

        .albumes .title {}
    </style>

    <section class="content-header d-none d-md-block">
        <div class="container-fluid d-flex justify-content-between align-items-center">


            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('manage.albumes.album', [$store->nickname, 0])); ?>">ALBUMES</a>
                </li>
                <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item"><a
                            href="<?php echo e(route('manage.albumes.album', [$store->nickname, $breadcrumb['id']])); ?>"><?php echo e(Str::upper($breadcrumb['name'])); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ol>

        </div><!-- /.container-fluid -->
    </section>


    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


        <div class="content-controls" wire:ignore>


            <?php if(isset($album_id)): ?>
                <div class="content-form">
                    <form method="POST" wire:ignore.self
                        action="<?php echo e(route('manage.albumes.upload', [$store->nickname, $album_id])); ?>"
                        class="dropzone d-flex flex-wrap justify-content-around p-3" id="my-awesome-dropzone-albums">
                    </form>
                </div>
            <?php endif; ?>


            <button class="btn btn-success mt-3" style="width: 145px;" data-toggle="modal" data-target="#addAlbum"
                type="button">+
                Agregar Carpeta</button>

        </div>

        <script>
            Dropzone.options.myAwesomeDropzoneAlbums = {
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                dictDefaultMessage: "<div class='add-photos'>Agregar + fotos al album </div> <i class=\"fas fa-camera mt-5\" style=\"font-size: 18pt;\"></i>",
                // acceptedFiles: "image/*",
                acceptedFiles: "*.jpg, .jpeg, .JPG, .JPEG",
                paramName: "file", // The name that will be used to transfer the file
                maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
                complete: function(file) {
                    this.removeFile(file);
                },
                queuecomplete: function() {
                    Livewire.emit('render');
                    //OJO REFRESCAMOS LA PAGINA PARA QUE DROPZONE VUELVA A LEER LOS NUEVOS FORMULARIOS AGREGADOS DINAMICAMENTE
                    window.location.reload()
                },
                accept: function(file, done) {
                    if (file.name == "justinbieber.jpg") {
                        done("Naha, you don't.");
                    } else {
                        done();
                    }
                }
            };
        </script>

        <div class="albumes mt-3">

            <?php $__currentLoopData = $albumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                

                <div class="card text-center ">

                    <a href="<?php echo e(route('manage.albumes.album', [$store->nickname, $album->id])); ?>">
                        <img class="p-3" src="<?php echo e(Storage::url('file.png')); ?>" alt="">
                    </a>

                    <div class="title text-center pb-3">
                        <h5><?php echo e($album->name); ?></h5>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'addAlbum']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'addAlbum']); ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'text','wirevalue' => 'name','icon' => 'fa-solid fa-font','debounce' => '250']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wirevalue' => 'name','icon' => 'fa-solid fa-font','debounce' => '250']); ?>
            Nombre carpeta
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <p>Albumes/<?php echo e($name); ?></p>

        <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled" wire.target="createPath"
            wire:click="createPath" class="btn btn-success ml-auto"><i class="fa-solid fa-floppy-disk mr-1"></i> Crear
            Carpeta</button>

        <div class="spinner-border" wire:loading.flex wire:target="createPath" role="status">
            <span class="sr-only">Loading...</span>
        </div>

        

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="d-flex flex-wrap justify-content-around">
            <?php $__currentLoopData = $album->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card text-center" style="width: 340px">

                    <a href="<?php echo e(Storage::disk('spaces')->url($photo->medium)); ?>" data-fancybox="gallery"
                        data-caption="<?php echo e($photo->name); ?>">

                        <img loading="lazy" src="<?php echo e(Storage::disk('spaces')->url($photo->medium)); ?>"
                            class="card-img-top" height="" alt="...">
                    </a>

                    <span><?php echo e($photo->name); ?></span>

                    <div class="controles d-flex justify-content-between p-3">

                        

                        <a target="_blank" href="<?php echo e(Storage::disk('spaces')->url($photo->large)); ?>"
                            class="btn btn-success"><i class="fa-solid fa-download me-1"></i>
                            Descargar</a>

                        <?php if($user->hasRole('admin')): ?>
                            <button type="button" wire:loading.attr="disabled"
                                wire.target="delete-<?php echo e($photo->id); ?>" wire:click="delete('<?php echo e($photo->large); ?>')"
                                class="btn btn-danger">
                                <i class="fa-solid fa-trash me-1"></i>Borrar</button>

                            <div wire:loading wire:target="delete-<?php echo e($photo->id); ?>" class="spinner-border"
                                role="status">
                                <span class="sr-only">Espere...</span>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/albumes/show-albumes.blade.php ENDPATH**/ ?>