<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['wirevalue', 'type' => 'text', 'disabled'=> '', 'icon' => '', 'texticon' => '', 'error' => '', 'label' => '', 'debounce' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['wirevalue', 'type' => 'text', 'disabled'=> '', 'icon' => '', 'texticon' => '', 'error' => '', 'label' => '', 'debounce' => '']); ?>
<?php foreach (array_filter((['wirevalue', 'type' => 'text', 'disabled'=> '', 'icon' => '', 'texticon' => '', 'error' => '', 'label' => '', 'debounce' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($label != ''): ?>
    <label for="" class="form-label"><?php echo e($label); ?></label>
<?php endif; ?>

<div class="mb-3">
    <div class="input-group mb-1">
        

        <?php if($texticon != '' || $icon != ''): ?>
            <div class="input-group-prepend">
                <span class="input-group-text">
                    <?php if($texticon != ''): ?>
                        <?php echo e($texticon); ?>

                    <?php else: ?>
                        <?php if($icon != ''): ?>
                            <i class="<?php echo e($icon); ?>"></i>
                        <?php endif; ?>
                    <?php endif; ?>
                </span>
            </div>
        <?php endif; ?>

        <?php if($debounce > 150): ?>
            <input type="<?php echo e($type); ?>" <?php echo e($disabled); ?> class="form-control" wire:model.debounce.<?php echo e($debounce); ?>ms="<?php echo e($wirevalue); ?>"
                aria-describedby="nameHelp" placeholder="<?php echo e($slot); ?>">
        <?php else: ?>
            <input type="<?php echo e($type); ?>" <?php echo e($disabled); ?> class="form-control" wire:model="<?php echo e($wirevalue); ?>"
                aria-describedby="nameHelp" placeholder="<?php echo e($slot); ?>">
        <?php endif; ?>

    </div>

    <?php if($error != ''): ?>
        <?php $__errorArgs = [$wirevalue];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class=" has-danger">
                <span class="form-control-feedback"><?php echo e($error); ?></span>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/form/input.blade.php ENDPATH**/ ?>