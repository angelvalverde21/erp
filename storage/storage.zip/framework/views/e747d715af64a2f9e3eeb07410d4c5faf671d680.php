<div>

    

    <?php echo $__env->make('livewire.components.addresses._form-address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/carriers/create-carrier.blade.php ENDPATH**/ ?>