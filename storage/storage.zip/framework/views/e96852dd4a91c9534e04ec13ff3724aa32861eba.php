<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id', 'accordionParentId', 'label', 'show' => false, 'icon' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'accordionParentId', 'label', 'show' => false, 'icon' => '']); ?>
<?php foreach (array_filter((['id', 'accordionParentId', 'label', 'show' => false, 'icon' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>




<div class="accordion-item">

    <h2 class="accordion-header" id="<?php echo e($id); ?>">

        <?php if($icon != ''): ?>
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse-<?php echo e($id); ?>" aria-expanded="true"
                aria-controls="collapse-<?php echo e($id); ?>">
                <i class="<?php echo e($icon); ?> me-2"></i> <strong><?php echo e($label); ?></strong>
            </button>
        <?php else: ?>
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse-<?php echo e($id); ?>" aria-expanded="true"
                aria-controls="collapse-<?php echo e($id); ?>">
                <strong><?php echo e($label); ?></strong>
            </button>
        <?php endif; ?>




    </h2>

    <?php if($show): ?>
        <div id="collapse-<?php echo e($id); ?>" class="accordion-collapse collapse show"
            aria-labelledby="<?php echo e($id); ?>" data-bs-parent="#<?php echo e($accordionParentId); ?>">
            <div class="accordion-body">
                <?php echo e($slot); ?>

            </div>
        </div>
    <?php else: ?>
        <div id="collapse-<?php echo e($id); ?>" class="accordion-collapse collapse"
            aria-labelledby="<?php echo e($id); ?>" data-bs-parent="#<?php echo e($accordionParentId); ?>">
            <div class="accordion-body">
                <?php echo e($slot); ?>

            </div>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/accordion-item.blade.php ENDPATH**/ ?>