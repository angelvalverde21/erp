<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => '', 'icon' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => '', 'icon' => '']); ?>
<?php foreach (array_filter((['title' => '', 'icon' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section class="content-header d-none d-md-block">
    <div class="container-fluid d-flex justify-content-between align-items-center">


        <?php if($icon != ''): ?>
            <h5><i class="<?php echo e($icon); ?> mr-2"></i> <?php echo e($title); ?></h5>
        <?php else: ?>
            <h5><?php echo e($title); ?></h5>
        <?php endif; ?>



        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="">Home</a></li>
            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
        </ol>

    </div><!-- /.container-fluid -->
</section>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/breadcrumbs.blade.php ENDPATH**/ ?>