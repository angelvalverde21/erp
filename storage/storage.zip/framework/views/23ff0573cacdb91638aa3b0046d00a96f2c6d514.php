<div>
    <!DOCTYPE html>
    <html lang="en" dir="ltr">

    

    <head>
        <meta charset="utf-8">
        <title>Label Packing</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <style>
            body {
                border: 1px solid #ccc;
                margin: 0px;
                font-family: sans-serif;
                font-size: 0.80rem;
                position: relative;
            }

            @page {
                margin: 0px;
                padding: 0px;
            }

            .label-left {
                border: 0px solid #ccc;
                width: 90mm;
                height: 133mm;
                position: absolute;
                top: 10mm;
                left: 10mm;
            }

            .label-right {
                border: 1px solid #ccc;
                width: 90mm;
                height: 133mm;
                position: absolute;
                top: 10mm;
                left: 110mm;
            }

            .logo {
                text-align: center;
                padding: 5px 0;
            }

            .logo img {
                width: auto;
                height: 60px;
                border: 0px solid #ccc
            }

            .ship-to {
                margin: 0 0px 5px 0px;
                padding: 3px 10px;
                background-color: #E1E1E1;
            }



            .ship-to .large {
                font-weight: bold;
                font-size: 12pt;
                margin: 0;
                padding: 0;
            }


            .ship-to p {
                margin: 0px;
                padding: 0px;
                border: 0px solid #000;
            }

            .ship-details ul {
                margin: 0;
                padding: 0 10px !important;
                border: 0px solid #ccc;
            }

            .sender-details {
                margin: 10px 0 0 0;
                padding: 0px 10px !important;
                border: 0px solid #ccc;
                background-color: #E1E1E1;
            }

            .qr {
                width: 100%;
                height: 32mm;
                position: relative;
                /* border: 1px solid #ccc; */
                margin: 10px 0 0;
                padding: 10px;
                top: 10px;
            }

            .yape {
                position: absolute;
                top: 0;
                left: 7.5mm;
                width: 25mm;
                height: 25mm;

                /* border: 1px solid #ccc; */
            }

            .plin {
                position: absolute;
                top: -3px;
                left: 57.5mm;
                width: 25mm;
                height: 25mm;
                /* border: 1px solid #ccc; */
                padding: 10px 5px 5px 5px;
                /* border-radius: 5px; */
            }

            .code {
                position: absolute;
                top: ;
                left: 32.5mm;
                width: 25mm;
                height: 25mm;
                border: 1px solid #ccc;
            }

            li {
                list-style: none;
                margin: 0;
                padding;
                0;
            }

            /*****/


            .barcode {
                text-align: center;
            }



            .qr {
                margin: 0;
                width: 30%;
                border: 0px solid #ccc;
                float: left;
            }

            .resumen {
                width: 60%;
                border: 0px solid #ccc;
                float: right;
                padding: 0 20px 0 0;
            }

            .status-pago {
                text-align: center;
                font-weight: bold;
                border: 0px solid #ccc;
                clear: both;
                font-size: 11pt;
                display: block;
            }

            .messages {
                position: absolute;
                bottom: 15px;
                left: 0px;
            }

            .total-ammount {
                position: absolute;
                top: 225px;
                left: 0px;
            }
        </style>
    </head>

    <body>

        <div class="label-left">
            <div class="logo mb-2">

                <?php if($order->store->getOption('upload_logo_invoice')): ?>
                    <img class="logo" src="<?php echo e($order->store->getOption('upload_logo_invoice')); ?>" alt="">
                <?php else: ?>
                    <h1 class="my-5">SU LOGO AQUI</h1>
                <?php endif; ?>

                
            </div>
            <div class="ship-to py-0">
                <p>DESTINATARIO: </p>
                <p class="large"><?php echo e(strtoupper($order->address->name)); ?></p>
            </div>

            <div class="ship-details">
                <ul class="my-2">
                    <li><span class="">DNI:</span> <?php echo e($order->address->dni); ?></li>
                    <li><span>CELULAR:</span> <?php echo e($order->address->phone); ?></li>
                    
                    <li><span class="">DIRECCION:</span> <?php echo e(strtoupper($order->address->primary)); ?></li>
                    <li><?php echo e($order->address->secondary); ?></li>
                    <li><?php echo e($order->address->district->name); ?> -
                        <?php echo e($order->address->district->province->name); ?> -
                        <?php echo e($order->address->district->province->department->name); ?></li>
                    <li>
                        
                        <span class="fw-bold">REFERENCIA:</span> <?php echo e(strtoupper($order->address->references)); ?>

                    </li>

                </ul>
            </div>

            <div class="sender-details">
                <li>REMITE: VANESA HINOSTROZA GONZALES</li>
                <li>DNI: 45631639</li>
                <li>CEL: 945101774</li>
                <li>Residencial Patria Nueva S/N, Los olivos - LIMA</li>
            </div>

            <style>
                .codigo-barras {}
            </style>

            <div class="codigo-barras my-3 text-center">
                <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG('011136', 'C39+', 2, 50)); ?>" alt="barcode" />
                <p style="font-size: 14pt">#011136</p>
            </div>

            

            <?php if(!$order->is_contra_entrega()): ?>
                <div class="carrier-address text-center">


                    <?php if($order->carrier_address): ?>
                        <li><?php echo e($order->carrier_address->title); ?></li>

                        <li><?php echo e($order->carrier_address->primary); ?>, <?php echo e($order->carrier_address->district->name); ?> -
                            <?php echo e($order->carrier_address->district->province->name); ?> -
                            <?php echo e($order->carrier_address->district->province->department->name); ?></li>
                    <?php else: ?>
                        <li>No se ha asignado transportista</li>
                    <?php endif; ?>

                </div>
            <?php endif; ?>

        </div>

        <div class="label-right">

            <?php if($order->is_contra_entrega()): ?>
                <div class="status-pago">
                    <h1>CONTRA ENTREGA</h1>
                </div>
            <?php endif; ?>

            <?php if($order->is_pay()): ?>
                <div class="status-pago">
                    <h1 class="mt-3">PAGADO</h1>
                    <hr>
                </div>
            <?php endif; ?>

            <div class="messages w-100">
                <div class="card mx-3">
                    <div class="card-body text-center">
                        <h5><?php echo e(Str::upper($order->observations_time)); ?></h5>
                    </div>
                </div>
            </div>


            <?php if($order->is_contra_entrega()): ?>
                <div class="total-ammount text-center w-100">
                    <h1>Total: S/. <?php echo e($order->total_amount); ?></h1>
                </div>
            <?php endif; ?>

            <?php if($order->is_contra_entrega()): ?>
                <div class="qr">
                    <div class="yape text-center">
                        
                        <span>YAPE</span>

                        <?php if($order->store->getOption('upload_qr_yape') != ''): ?>
                            <img src="<?php echo e($order->store->getOption('upload_qr_yape')); ?>" alt="barcode" height="130"
                                width="130" />
                        <?php else: ?>
                            <h3>Aqui debe ir su Qr de Yape</h3>
                        <?php endif; ?>


                    </div>

                    
                    <div class="plin text-center">
                        <span>PLIN</span>

                        <?php if($order->store->getOption('upload_qr_plin') != ''): ?>
                            <img src="<?php echo e($order->store->getOption('upload_qr_plin')); ?>" alt="barcode" height="130"
                                width="130" />
                        <?php else: ?>
                            <h3>Aqui debe ir su Qr de Plin</h3>
                        <?php endif; ?>


                    </div>

                </div>
            <?php endif; ?>



        </div>

        

        


    </body>

    </html>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/print/packing-label.blade.php ENDPATH**/ ?>