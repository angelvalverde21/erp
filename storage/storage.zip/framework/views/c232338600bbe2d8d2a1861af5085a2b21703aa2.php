<div>

    <style>
        .dropzone {
            width: 100% !important;
            height: 75px;
            min-height: 0px !important;
        }

        .dropzone .dz-message {
            margin: 0;
        }
    </style>

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.card-upload-user','data' => ['wirekey' => 'a1','filename' => ''.e($user->$field).'','userid' => ''.e($user->id).'','field' => ''.e($field).'','iddrop' => 'my-awesome-dropzone-photo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.card-upload-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirekey' => 'a1','filename' => ''.e($user->$field).'','userid' => ''.e($user->id).'','field' => ''.e($field).'','iddrop' => 'my-awesome-dropzone-photo']); ?>
        <?php echo e($field); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php $__env->startPush('script'); ?>
        <script>
            
            Livewire.on('uploadPhotoJs', (UserId, deleteFunction) => {

                Swal.fire({
                    title: 'Esta seguro?',
                    text: "De borrar el comprobante",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'No',
                    confirmButtonText: 'Si'
                }).then((result) => {

                    if (result.isConfirmed) {
                        Swal.fire(
                            'Borrado!',
                            'El archivo ha sido borrado',
                            'success'
                        );
                        //console.log('borrado');
                        Livewire.emit('deleteFileProfile', UserId, deleteFunction)
                        //deleteFileProfile se encuentra en el archivo componente card-upload-user
                    }

                })

            })

            Dropzone.options.myAwesomeDropzonePhoto = {
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                dictDefaultMessage: "<i class=\"fas fa-camera mt-10\" style=\"font-size: 18pt;\"></i>",
                acceptedFiles: "image/*",
                paramName: "file", // The name that will be used to transfer the file
                maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
                complete: function(file) {
                    this.removeFile(file);
                },
                queuecomplete: function() {
                    Livewire.emit('refreshCard');
                },
                accept: function(file, done) {
                    if (file.name == "justinbieber.jpg") {
                        done("Naha, you don't.");
                    } else {
                        done();
                    }
                }
            };
        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/profile/card-upload.blade.php ENDPATH**/ ?>