<div>

    <?php $__env->startPush('script-header'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['title' => 'Productos','icon' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Productos','icon' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Buscar" wire:model.debounce.500ms="search" aria-label="Recipient's username" aria-describedby="basic-addon2">
            
            <span class="input-group-text" id="basic-addon2"><i class="fa-solid fa-magnifying-glass"></i></span>
          </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="card">
            <div class="card-header py-3">
                <a href="<?php echo e(route('manage.products.create', [$store->nickname])); ?>"
                    class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i> Crear
                    producto</a>
            </div>

            
            <!-- /.card-header -->
            <div class="card-body table-responsive">

                <table id="example" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th class="text-center">Imagen</th>
                            <th>Nombre</th>
                            <th class="text-center">Descargar</th>
                            <th>Costo</th>
                            <th>Precio</th>
                            <th>Publicado</th>

                            <th>Acciones</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>

                                <td class="text-center">

                                    <?php if($product->images->count() or $product->colors->count()): ?>

                                    

                                    
                                    

                                        <a href="<?php echo e(route('manage.products.edit', [$store->nickname, $product->id])); ?>">
                                            <img loading="lazy" width="75" src="<?php echo e(Storage::url($product->image())); ?>" alt="">
                                        </a>
                                        
                                    <?php else: ?>

                                        <a style="color: rgb(100, 100, 100);"
                                            href="<?php echo e(route('manage.products.edit', [$store->nickname, $product->id])); ?>"><span
                                                style="font-size: 50px;"><i
                                                    class="fa-solid fa-image"></i></span></a>

                                    <?php endif; ?>
                                    (<?php echo e($product->quantity); ?>)
                                </td>

                                <td><a href="<?php echo e(route('manage.products.edit', [$store->nickname, $product->id])); ?>"><?php echo e($product->name); ?></a></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('manage.products.download.zip', [$store->nickname, $product->id])); ?>" style="width: 75px; margin: 0 auto;"  class="btn btn-success btn-erp d-flex justify-content-between align-items-center"><i class="fa-solid fa-download me-2"></i> <span>Stock</span></a>
                                </td>
                                <td>S/. <?php echo e($product->costo); ?></td>
                                <td>S/. <?php echo e($product->price); ?></td>
                                <td><?php echo e($product->created_at); ?></td>
                                <td>
                                    <div class="d-flex  justify-content-center">
                                        <a href="<?php echo e(route('manage.products.edit', [$store->nickname, $product->id])); ?>"
                                            class="btn btn-success mr-2"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="#" wire:click.prevent="deleteProduct(<?php echo e($product->id); ?>)" class="btn btn-secondary"><i
                                                class="fa-solid fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>


            </div>
            <!-- /.card-body -->
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/show-products.blade.php ENDPATH**/ ?>