<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['target', 'class'=>'secondary', 'text'=>'Editar','icon'=>'fa-solid fa-pen-to-square']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['target', 'class'=>'secondary', 'text'=>'Editar','icon'=>'fa-solid fa-pen-to-square']); ?>
<?php foreach (array_filter((['target', 'class'=>'secondary', 'text'=>'Editar','icon'=>'fa-solid fa-pen-to-square']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<a class="btn btn-<?php echo e($class); ?>" href="#" data-toggle="modal" data-target="<?php echo e($target); ?>"><i class="<?php echo e($icon); ?> mr-1"></i> <?php echo e($text); ?></a><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/user/button-open-modal.blade.php ENDPATH**/ ?>