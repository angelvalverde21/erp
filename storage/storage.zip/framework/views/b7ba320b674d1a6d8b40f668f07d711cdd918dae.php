<nav class="navbar navbar-expand-lg">

    <li class="nav-item active mr-2 mt-2">
        <a class="btn btn-outline-success"
            href="<?php echo e(route('manage.customers.edit', [$store->nickname, $order->buyer_id])); ?>"><i
                class="fa-solid fa-user me-1"></i>
             (<?php echo e($order->buyer->totalOrders()); ?>)</a>

             
        <a class="btn btn-success"
            href="<?php echo e(route('manage.orders.create.with.user', [$store->nickname, $order->buyer_id])); ?>"><i
                class="fa-solid fa-receipt me-1"></i> Crear Orden</a>
    </li>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse mt-2" id="navbarNav">

        <ul class="navbar-nav ml-auto d-flex align-self-center">

            <li class="nav-item active">
                <div class="dropdown ">
                    <button class="btn btn-outline-info w-100 my-1 dropdown-toggle" type="button"
                        id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-solid fa-print mr-2 pt-1"></i> Imprimir
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start dropdown-menu-right"
                        aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" target="_blank" href="<?php echo e(route('manage.orders.print.invoice', [$store->nickname, $order->id])); ?>"><i class="fa-solid fa-clipboard-list mr-1"></i>
                                Orden de compra</a></li>
                        <div class="dropdown-divider"></div>
                        <li><a class="dropdown-item" target="_blank"
                                href="<?php echo e(route('manage.orders.print.packing-label', [$store->nickname, $order->id])); ?>" target="_blank"><i
                                    class="fa-solid fa-box-open mr-1"></i>
                                Rotulado</a></li>
                        <div class="dropdown-divider"></div>
                        <li><a class="dropdown-item" target="_blank"
                                href="<?php echo e(route('manage.orders.print.voucher', [$store->nickname, $order->id])); ?>"><i
                                    class="fa-solid fa-receipt mr-2 pt-1"></i> Voucher</a></li>
                    </ul>
                </div>
            </li>

            

            <li class="nav-item active">
                <a class="btn btn-outline-info d-flex my-1" data-toggle="modal" data-target="#observations-modal"
                    href="#"><i class="fa-solid fa-message mr-2 pt-1"></i>
                    Observaciones</a>
            </li>


            
            <?php $__env->startPush('script'); ?>
                <script>
                    // enviando datos al servidor
                    document.addEventListener('livewire:load', function() {
                        window.livewire.find('<?php echo e($_instance->id); ?>').current = current;
                        console.log(current);
                    })
                </script>
            <?php $__env->stopPush(); ?>

            

        </ul>
    </div>

</nav>

<nav>
    
    <li class="nav-item d-flex justify-content-between w-100 mb-2 mt-1">
        <div class="registrado">Registrado: <?php echo e($order->created_at); ?></div>
        <div class="actualizado">Ultima Actualizacion: <?php echo e($order->updated_at); ?></div>
    </li>
    
</nav>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Observaciones','id' => 'observations-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Observaciones','id' => 'observations-modal']); ?>

    <div class="row">
        <div class="col-lg-12">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.textarea','data' => ['wirevalue' => 'order.observations_time','id' => 'o1','label' => 'Observaciones de la entrega (Horario)','icon' => 'fa-solid fa-lock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'order.observations_time','id' => 'o1','label' => 'Observaciones de la entrega (Horario)','icon' => 'fa-solid fa-lock']); ?>
                Observaciones de la entrega (Horario)
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.textarea','data' => ['wirevalue' => 'order.observations_public','id' => 'o2','label' => 'Observaciones publicas','icon' => 'fa-solid fa-unlock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'order.observations_public','id' => 'o2','label' => 'Observaciones publicas','icon' => 'fa-solid fa-unlock']); ?>
                Observaciones publicas
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.textarea','data' => ['wirevalue' => 'order.observations_private','id' => 'o3','label' => 'Observaciones internas','icon' => 'fa-solid fa-lock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'order.observations_private','id' => 'o3','label' => 'Observaciones internas','icon' => 'fa-solid fa-lock']); ?>
                Observaciones Internas
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
        <div class="col-lg-12"></div>
    </div>

     <?php $__env->slot('footer', null, []); ?> 
        <button type="button" class="btn btn-info" wire:loading.attr="disabled" wire.target="save"
            wire:click="saveObservations"><i class="fa-solid fa-floppy-disk mr-1"></i> Guardar
        </button>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/_navbar-buttons.blade.php ENDPATH**/ ?>