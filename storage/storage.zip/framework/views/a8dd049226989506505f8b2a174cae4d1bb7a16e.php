<div>
    
    <div class="mb-3">
        <div class="input-group mb-3">
            <input type="hidden" wire:model="address.user_id">
        </div>
    </div>

    <div>

        <hr>
    
        <?php echo $__env->make('livewire.components.addresses._form-address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    </div>
    

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/addresses/create-address.blade.php ENDPATH**/ ?>