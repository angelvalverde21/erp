<div>

    <style>
        .separador-sidebar {
            background: #858585;
            width: 100%;
            height: 0.50px;
        }

        .nav-sidebar>.nav-item .nav-icon {
            font-size: 0.9rem !important;
        }

        .user-panel {
            font-size: 0.9rem !important;
        }
    </style>


    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->

        <!-- Sidebar -->
        <div class="sidebar">


            <div class="logo-store px-3 pt-3 text-center">
                <?php if($store->getOption('upload_logo') != ''): ?>
                    <img width="100px" src="<?php echo e($store->getOption('upload_logo')); ?>" alt="">
                <?php else: ?>
                    <h3>SU LOGO AQUI</h3>
                <?php endif; ?>
            </div>
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex justify-content-between text-white">

                <div class="image">
                    <img src="<?php echo e(asset('admin-lte/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2"
                        alt="User Image">
                </div>

                <div class="info">
                    <div class="name text-end">
                        <a href="<?php echo e(route('home')); ?>" class="d-block"><?php echo e($user->name); ?> </a>
                    </div>

                    <div class="rol text-end">
                        <?php if($user->hasRole('admin')): ?>
                            Admin
                        <?php endif; ?>
                    </div>

                </div>
            </div>

            <?php if(isset($store->nickname)): ?>
                <!-- SidebarSearch Form -->

                <div class="form-inline">
                    <div class="input-group" data-widget="sidebar-search">
                        <input class="form-control form-control-sidebar" type="search" placeholder="Search"
                            aria-label="Search">
                        <div class="input-group-append">
                            <button class="btn btn-sidebar">
                                <i class="fas fa-search fa-fw"></i>
                            </button>
                        </div>
                    </div>
                </div>

                

                


                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(isset($menu['sub_menu'])): ?>
                        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                            <div class="info">
                                <a href="#" class="d-block"><i class="<?php echo e($menu['icon']); ?> mr-2"></i>
                                    <?php echo e($menu['name']); ?></a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                            <div class="info">
                                <a href="<?php echo e($menu['slug']); ?>" class="d-block"><i class="<?php echo e($menu['icon']); ?> mr-2"></i>
                                    <?php echo e($menu['name']); ?></a>
                            </div>
                        </div>
                    <?php endif; ?>



                    <!-- sub menu -->

                    <nav class="mt-2">

                        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="" role="menu"
                            data-accordion="">

                            <?php if(isset($menu['sub_menu'])): ?>
                                <?php $__currentLoopData = $menu['sub_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e($sub_menu['slug']); ?>"
                                            class="nav-link <?php echo e(request()->routeIs('manage.' . $sub_menu['active'], [$store->nickname]) ? 'active' : ''); ?>">
                                            
                                            <i class="<?php echo e($sub_menu['icon']); ?> nav-icon"></i>
                                            <p><?php echo e($sub_menu['name']); ?></p>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </ul>
                    </nav>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                <!-- sub menu -->

                

                
                

                


                
            <?php else: ?>
                
                <!-- Sidebar Menu -->

                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="info">
                        <a href="<?php echo e(route('account')); ?>" class="d-block"><i
                                class="fa-solid fa-store mr-2"></i>Paginas</a>
                    </div>
                </div>

                <nav class="mt-2">

                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="" role="menu" data-accordion="">
                        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->


                        
                        <li class="nav-item">

                            <a href="<?php echo e(route('account.store.create')); ?>" class="nav-link"><i
                                    class="fa-solid fa-box nav-icon"></i>Crear nueva pagina</a>

                        </li>

                    </ul>
                </nav>
            <?php endif; ?>


        </div>
        <!-- /.sidebar -->



    </aside>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/components/sidebar.blade.php ENDPATH**/ ?>