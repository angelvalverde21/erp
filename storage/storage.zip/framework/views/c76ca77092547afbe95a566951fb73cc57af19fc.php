<div>

    <div class="row mt-3">

        <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
            <div class="info-box">
                <?php if($order->is_preparing()): ?>
                    <span class="info-box-icon bg-success elevation-1"><i class="fa-solid fa-cart-flatbed"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">PREPARANDO </span>
                        <span class="info-box-number">
                            ENVIO
                        </span>
                    </div>
                <?php else: ?>
                    <span class="info-box-icon bg-secondary elevation-1"><i class="fa-solid fa-cart-flatbed"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">PREPARANDO </span>
                        <span class="info-box-number">
                            ENVIO
                        </span>
                    </div>
                <?php endif; ?>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>

        <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
            <div class="info-box mb-3">
                <?php if($order->is_ready_delivery()): ?>
                    <span class="info-box-icon bg-success elevation-1"><i class="fa-solid fa-dolly"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">LISTO PARA</span>
                        <span class="info-box-number">ENVIO</span>
                    </div>
                <?php else: ?>
                    <span class="info-box-icon bg-secondary elevation-1"><i class="fa-solid fa-dolly"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">LISTO PARA</span>
                        <span class="info-box-number">ENVIO</span>
                    </div>
                <?php endif; ?>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
            <div class="info-box">
                <span class="info-box-icon bg-secondary elevation-1"><i class="fa-solid fa-truck-fast"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">EN</span>
                    <span class="info-box-number">
                        TRANSITO
                    </span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>

        <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
            <div class="info-box mb-3">

                <?php if($order->is_delivered()): ?>
                    <span class="info-box-icon bg-success elevation-1"><i class="fa-solid fa-paper-plane"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">ENTREGADO</span>
                        <span class="info-box-number">16-01-2022</span>
                    </div>
                <?php else: ?>
                    <?php if($order->is_active): ?>
                        <span class="info-box-icon bg-secondary elevation-1"><i
                                class="fa-solid fa-paper-plane"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">PENDIENTE</span>
                            <span class="info-box-number">ENTREGA</span>

                        </div>
                    <?php else: ?>
                        <span class="info-box-icon bg-danger elevation-1"><i
                                class="fa-solid fa-ban"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">ORDEN</span>
                            <span class="info-box-number">CANCELADA</span>

                        </div>
                    <?php endif; ?>


                <?php endif; ?>


                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>

        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/card-status-iconos.blade.php ENDPATH**/ ?>