<div>
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.button-open-modal','data' => ['class' => 'success mb-3','text' => 'Agregar Pago','icon' => 'fa-solid fa-plus','target' => '#agregarPago']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'success mb-3','text' => 'Agregar Pago','icon' => 'fa-solid fa-plus','target' => '#agregarPago']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if($order->is_pay()): ?>
        Esta pagado
    <?php else: ?>   
        falta pagar
    <?php endif; ?>

    <div class="table-responsive">
        <?php if($order->payments->count() > 0): ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th style="width: 10px" class="text-center">#</th>
                    <th class="text-center">Imagen</th>
                    <th>Subido</th>
                    <th>Medio de pago</th>
                    <th>Monto</th>
                    <th style="width: 40px">Status</th>
                    <th class="text-center">Delete</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $order->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($payment->id); ?></td>
                        <td class="text-center">
                            
                            <a href="<?php echo e(Storage::url($payment->image)); ?>" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
                                <img class="imagen-comprobante" src="<?php echo e(Storage::url($payment->image)); ?>" height="60px" alt="">
                            </a>

                        </td>
                        <td><?php echo e($payment->created_at); ?></td>
                        <td>
                            <?php echo e($payment->payment_method->name); ?>

                        </td>
                        <td><?php echo e($payment->amount); ?></td>
                        <td><span class="badge bg-success"><?php echo e($payment->status->title); ?></span></td>
                        <td class="text-center"><button type="button" wire:loading:click wire:click="deletePayment(<?php echo e($payment->id); ?>)" class="btn btn-danger">X</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <?php else: ?>
            <div class="alert p-3">
                No hay pagos registrados para esta orden
            </div>
        <?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Agregar pago','id' => 'agregarPago']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar pago','id' => 'agregarPago']); ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-upload-order','data' => ['post' => 'manage.orders.upload.invoice','wirekey' => 'a1','filename' => ''.e($order->photo_payment).'','orderid' => ''.e($order->id).'','store' => ''.e($store->nickname).'','iddrop' => 'upload-invoice','bg' => 'light']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-upload-order'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => 'manage.orders.upload.invoice','wirekey' => 'a1','filename' => ''.e($order->photo_payment).'','orderid' => ''.e($order->id).'','store' => ''.e($store->nickname).'','iddrop' => 'upload-invoice','bg' => 'light']); ?>
            <i class="fa-solid fa-file-invoice-dollar mr-2"></i> Vaucher de pago
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <div class="input-group mb-3">
            <span class="input-group-text">S/.</span>
            <input type="text" class="form-control" id="total_amount" value="<?php echo e($order->total_amount); ?>" aria-label="">
        </div>

        <div class="payment_type mb-3">
            <?php echo $__env->make('livewire.manage.orders.edit-order._navbar-pay-method', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <button type="button" class="btn btn-success w-100" id="registrarPago">Registrar
            Pago</button>

        

        

         <?php $__env->slot('footer', null, []); ?> 

         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


    <script>

        Dropzone.options.uploadInvoice = {
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            dictDefaultMessage: "<i class=\"fas fa-camera mt-10\" style=\"font-size: 18pt;\"></i>",
            acceptedFiles: "image/*",
            paramName: "file", // The name that will be used to transfer the file
            addRemoveLinks: true,
            maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
            autoProcessQueue: false,
            maxFiles: 1,
            // uploadMultiple: true,

            init: function() {

                console.log('init');

                //Desactiva el boton
                // document.getElementById('registrarPago').setAttribute('disabled', 'disabled');

                // document.getElementById('registrarPago').setAttribute('disabled', 'disabled');

                var myDropzone = this;

                // for Dropzone to process the queue (instead of default form behavior):
                document.getElementById("registrarPago").addEventListener("click", function(e) {
                    // Make sure that the form isn't actually being sent.
                    e.preventDefault();
                    e.stopPropagation();
                    myDropzone.processQueue();
                    console.log('registrarPago');
                    //Desactiva el boton

                });

                // send all the form data along with the files:
                // this.on("sendingmultiple", function(data, xhr, formData) {
                //     formData.append("total_amount", jQuery("#total_amount").val());
                // });

                this.on("sending", function(data, xhr, formData) {
                    formData.append("total_amount", jQuery("#total_amount").val());
                    formData.append("payment_method_id", jQuery(".payment_type #payment_method_id").val());
                    console.log('sending');
                });

                this.on("addedfile", function(data, xhr, formData) {
                    console.log('se agrego un archivo');

                    //Activa el boton para poder enviar
                    // document.getElementById("registrarPago").removeAttribute('disabled');
                    console.log('addedfile');
                });

                // eventos
                // queuecomplete
                // sendingmultiple
                // sending

                //desactiva el boton 
                // document.getElementById('registrarPago').setAttribute('disabled', 'disabled');

            },

            complete: function(file) {
                this.removeFile(file);
                console.log('complete');

            },
            queuecomplete: function() {
                Livewire.emit('refreshOrder');
                Livewire.emit('render');
                console.log('queuecomplete');
                // document.getElementById('registrarPago').setAttribute('disabled', 'disabled');
            },

            accept: function(file, done) {

                console.log('accept');

                if (file.name == "justinbieber.jpg") {
                    done("Naha, you don't.");
                } else {
                    done();
                }
            }
        };
    </script>

    

</div>


<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $("#total_amount").keyup(function() {
                document.getElementById("registrarPago").removeAttribute('disabled');
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/card-show-invoice.blade.php ENDPATH**/ ?>