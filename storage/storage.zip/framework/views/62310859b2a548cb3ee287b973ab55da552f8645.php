<div>

    <hr>

    <?php echo $__env->make('livewire.components.addresses._form-address', [ 'form_type'=> 'update', 'component'=>'user.sales.edit-sale.addresses.edit-address' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/addresses/edit-address.blade.php ENDPATH**/ ?>