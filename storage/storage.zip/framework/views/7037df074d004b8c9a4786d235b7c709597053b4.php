<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title','titlesmall'=>""]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title','titlesmall'=>""]); ?>
<?php foreach (array_filter((['title','titlesmall'=>""]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="card mt-3">

    <div class="card-header">
        <div><?php echo e($title); ?> </div><small><?php echo e($titlesmall); ?></small>
    </div>

    <div class="card-body">

        <?php echo e($slot); ?>


    </div>

    <div class="card-footer d-flex">
        <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled" wire.target="save"
            wire:click="save" class="btn btn-primary ml-auto"><i class="fa-solid fa-floppy-disk mr-1"></i> Guardar
            Cambios</button>

        <div class="spinner-border" wire:loading.flex wire:target="save" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/cardsave.blade.php ENDPATH**/ ?>