<div>

    

    <div class="row pb-3" wire:ignore>

        <div class="col position-relative">

            <form method="POST" action="<?php echo e(route('manage.products.upload.images', [$store->nickname, $product])); ?>" class="dropzone"
                id="my-awesome-dropzone-images">

            </form>
        </div>

    </div>

    <style>
        /* .contenedor{
            display: flex;
            flex-wrap: wrap;
            width: 100%;
            gap: 20px;
        } */

        .contenedor {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(15rem , 1fr));
            /*3 columnas del tamaño de una fraccion*/
            gap: 20px;

        }

        .contenedor .card {
            margin-bottom: 0;
            min-height: 150px;
            position: relative;
        }

        .btn-eliminar-imagen{
            position: absolute;
            bottom: 10px;
            right: 20px;
        }
    </style>

    
    <?php if($product->images->count()): ?>

        
        <div class="contenedor">

            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">

                    <div class="image">
                        <img src="<?php echo e(Storage::url($image->name)); ?>"
                        alt="" width="100%" height="100%">

                    </div>

                        
                        <div class="btn-eliminar-imagen" wire:key="image-<?php echo e($image->id); ?>">
                            <a style="font-size: 15pt; color:rgb(44, 44, 44)" href="#"  wire:click.prevent="deleteImage(<?php echo e($image->id); ?>)" wire:loading.attr="disabled"
                                wire:target="deleteImage(<?php echo e($image->id); ?>)"
                                ><i class="fa-solid fa-trash"></i></a>
                        </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    <?php endif; ?>


    <?php $__env->startPush('script'); ?>
        <script>
            Dropzone.options.myAwesomeDropzoneImages = {
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                dictDefaultMessage: "<div>Agregar fotos para la portada de este producto</div> <i class=\"fas fa-camera mt-15\" style=\"font-size: 18pt;\"></i>",
                acceptedFiles: "image/*",
                paramName: "file", // The name that will be used to transfer the file
                maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
                complete: function(file) {
                    this.removeFile(file);
                },
                queuecomplete: function() {
                    Livewire.emit('refreshImages');
                },
                accept: function(file, done) {
                    if (file.name == "justinbieber.jpg") {
                        done("Naha, you don't.");
                    } else {
                        done();
                    }
                }
            };
        </script>

    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product/images.blade.php ENDPATH**/ ?>