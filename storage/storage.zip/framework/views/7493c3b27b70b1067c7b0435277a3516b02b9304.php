<div>
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.button-open-modal','data' => ['class' => 'success mb-3','text' => 'Agregar','icon' => 'fa-solid fa-plus','target' => '#agregarComprobantes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'success mb-3','text' => 'Agregar','icon' => 'fa-solid fa-plus','target' => '#agregarComprobantes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="table-responsive">
        <?php if($order->comprobantesEmpaque->count() > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 10px" class="text-center">#</th>
                        <th class="text-center">Imagen</th>
                        <th>Subido</th>
                        <th class="text-center">Delete</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $order->comprobantesEmpaque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comprobante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($comprobante->id); ?></td>
                            <td class="text-center"><img class="imagen-comprobante" src="<?php echo e(Storage::url($comprobante->name)); ?>" height="60px" alt="">
                            <td><?php echo e($comprobante->created_at); ?></td>
                            </td>
                            <td class="text-center"><button type="button" wire:loading:click
                                    wire:click="deleteComprobante(<?php echo e($comprobante->id); ?>)" class="btn btn-danger">X</button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        <?php else: ?>
            <div class="alert p-3">
                No hay comprobantes de empaque para esta orden
            </div>
        <?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Agregar pago','id' => 'agregarComprobantes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar pago','id' => 'agregarComprobantes']); ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-upload-order','data' => ['size' => 'modal-lg','post' => 'manage.orders.upload.comprobantes.empaque','wirekey' => 'a1','filename' => ''.e($order->photo_payment).'','orderid' => ''.e($order->id).'','store' => ''.e($store->nickname).'','iddrop' => 'upload-comprobantes-empaque','bg' => 'light']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-upload-order'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'modal-lg','post' => 'manage.orders.upload.comprobantes.empaque','wirekey' => 'a1','filename' => ''.e($order->photo_payment).'','orderid' => ''.e($order->id).'','store' => ''.e($store->nickname).'','iddrop' => 'upload-comprobantes-empaque','bg' => 'light']); ?>
            <i class="fa-solid fa-file-invoice-dollar mr-2"></i> Adjuntar comprobantes
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        

        

         <?php $__env->slot('footer', null, []); ?> 

         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


    <script>
        Dropzone.options.uploadComprobantesEmpaque = {
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            dictDefaultMessage: "<i class=\"fas fa-camera mt-10\" style=\"font-size: 18pt;\"></i>",
            acceptedFiles: "image/*",
            paramName: "file", // The name that will be used to transfer the file
            addRemoveLinks: true,
            maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
            // autoProcessQueue: false, //espara que no se envie automaticamente, pero en este casi si deseamos eso
            // maxFiles: 1,
            // uploadMultiple: true,

            init: function() {

                console.log('init');

                var myDropzone = this;

                // for Dropzone to process the queue (instead of default form behavior):
                // document.getElementById("registrarPago").addEventListener("click", function(e) {
                //     // Make sure that the form isn't actually being sent.
                //     e.preventDefault();
                //     e.stopPropagation();
                //     myDropzone.processQueue();
                //     console.log('registrarPago');
                //     //Desactiva el boton

                // });

                // send all the form data along with the files:
                // this.on("sendingmultiple", function(data, xhr, formData) {
                //     formData.append("total_amount", jQuery("#total_amount").val());
                // });

                // this.on("sending", function(data, xhr, formData) {
                //     formData.append("total_amount", jQuery("#total_amount").val());
                //     formData.append("payment_method_id", jQuery(".payment_type #payment_method_id").val());
                //     console.log('sending');
                // });

                // this.on("addedfile", function(data, xhr, formData) {
                //     console.log('se agrego un archivo');
                //     console.log('addedfile');
                // });

                // eventos
                // queuecomplete
                // sendingmultiple
                // sending

                //desactiva el boton 
                // document.getElementById('registrarPago').setAttribute('disabled', 'disabled');

            },

            complete: function(file) {
                this.removeFile(file);
                console.log('complete');

            },
            queuecomplete: function() {
                Livewire.emit('refreshOrder');
                console.log('queuecomplete');
                // document.getElementById('registrarPago').setAttribute('disabled', 'disabled');
            },

            accept: function(file, done) {

                console.log('accept');

                if (file.name == "justinbieber.jpg") {
                    done("Naha, you don't.");
                } else {
                    done();
                }
            }
        };
    </script>

    

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/card-comprobantes-empaque.blade.php ENDPATH**/ ?>