<div>
    

    
    <?php $__currentLoopData = $selectedRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectedRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-switch">

            <?php if($selectedRole['has_role']): ?>
                <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault-<?php echo e($selectedRole['name']); ?>" wire:click="removeAdd('<?php echo e($selectedRole['name']); ?>')" checked>
            <?php else: ?>
                <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault-<?php echo e($selectedRole['name']); ?>" wire:click="removeAdd('<?php echo e($selectedRole['name']); ?>')">
            <?php endif; ?>

            <label class="form-check-label" for="flexSwitchCheckDefault-<?php echo e($selectedRole['name']); ?>"><?php echo e($selectedRole['name']); ?></label>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/roles/show-roles.blade.php ENDPATH**/ ?>