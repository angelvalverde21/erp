<div>
    
    <div class="card">
        <div class="card-header bg bg-dark">Agregar Oficina</div>
        <div class="card-body">
            <?php echo $__env->make('livewire.components.addresses._form-address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/carriers/create-office-carrier.blade.php ENDPATH**/ ?>