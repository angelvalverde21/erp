<div>


    <style>
        .dropzone {
            width: 100% !important;
            height: 150px;
            min-height: 0px !important;
        }

        .dropzone .dz-message {
            margin: 0;
        }
    </style>


    
    <div class="zoom-color text-center">

        <div wire:ignore class="drop-zoom" wire:key="upload-option-<?php echo e($field); ?>">

            <form method="POST" action="<?php echo e(route('manage.option.upload', [$store->nickname])); ?>" class="dropzone"
                id="my-awesome-dropzone-upload-option-<?php echo e($field); ?>">
            </form>

        </div>

        <div class="preview py-3">
            <a href="<?php echo e($image); ?>" data-lightbox="<?php echo e($field); ?>"><img src="<?php echo e($image); ?>"
                    width="140px" alt=""></a>

        </div>

    </div>

    <?php $__env->startPush('script'); ?>
        <script>
            Dropzone.options.myAwesomeDropzoneUploadOption<?php echo e($fieldPascalCase); ?> = {
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                dictDefaultMessage: "<div><?php echo e($text); ?></div> <i class=\"fas fa-camera mt-5\" style=\"font-size: 18pt;\"></i>",
                acceptedFiles: "image/*",
                paramName: "file", // The name that will be used to transfer the file
                params: {
                    'name': '<?php echo e($field); ?>',
                    'user_id': '<?php echo e($user_id); ?>', //esto lo recibe la funcion en el controller
                },
                maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor

                complete: function(file) {
                    this.removeFile(file);
                },
                queuecomplete: function() {
                    Livewire.emit('refreshOptionUpload');
                },
                accept: function(file, done) {
                    if (file.name == "justinbieber.jpg") {
                        done("Naha, you don't.");
                    } else {
                        done();
                    }
                }
            };
        </script>
    <?php $__env->stopPush(); ?>


</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/profile/upload-option.blade.php ENDPATH**/ ?>