<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['label' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['label' => '']); ?>
<?php foreach (array_filter((['label' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button type="button" wire:loading.class="btn-secondary"
    wire:loading.attr="disabled" wire.target="save"
    wire:click="save" class="btn btn-success ml-auto">
    <i class="fa-solid fa-floppy-disk mr-1"></i> 
    <span>
        Guardar Cambios
    </span>
</button>
                
<div class="spinner-border" wire:loading.flex wire:target="save" role="status">
    <span class="sr-only">Loading...</span>
</div><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/form/save.blade.php ENDPATH**/ ?>