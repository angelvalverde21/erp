<div>
    
    <a class="btn btn-primary" href="#" data-toggle="modal" data-target="#addImagesColor<?php echo e($color->id); ?>" style="width: 125px;" class="d-flex justify-content-between align-items-center">
        <i class="fa-solid fa-palette me-1"></i><span> Editar Color</span>
    </a>
    <p>Agregue fotos del mismo color pero actuales</p>

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Agregar variantes','id' => 'addImagesColor'.e($color->id).'','size' => 'modal-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar variantes','id' => 'addImagesColor'.e($color->id).'','size' => 'modal-lg']); ?>

        <div class="zoom-color">
            <div wire:ignore class="drop-zoom" wire:key="color-variants-form-upload-<?php echo e($color->id); ?>">

                <form method="POST"
                    action="<?php echo e(route('manage.products.upload.colors.variants', [$store->nickname, $color])); ?>"
                    class="dropzone" id="my-awesome-dropzone-variants-colors-edit">
                </form>

            </div>
        </div>

        <div class="input-group mb-3 mt-3">
            <input type="text" class="form-control" wire:model.debounce.500ms="color.label" placeholder="Color"
                aria-label="Color" aria-describedby="basic-addon1">
        </div>

        <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled" wire.target="save"
            wire:click="save" class="btn btn-success ml-auto"><i class="fa-solid fa-floppy-disk mr-1"></i> Guardar
            Cambios</button>

        <div class="spinner-border" wire:loading.flex wire:target="save" role="status">
            <span class="sr-only">Loading...</span>
        </div>


        <table class="table table-striped mt-3">
            <tr>
                <td>#</td>
                <td>Color</td>
                <td>Created at</td>
                <td></td>
            </tr>

            <?php if($color->images->count() == 1): ?>
                <?php $__currentLoopData = $color->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($image->id); ?></td>
                        <td><img src="<?php echo e(Storage::url($image->name)); ?>" width="100px" height="100%" alt="">
                        </td>
                        <td><?php echo e($image->created_at); ?></td>
                        <td wire:key="color-variante-<?php echo e($image->id); ?>" class="text-center">
                            Para borrar, Agregue otra imagen
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $color->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($image->id); ?></td>
                        <td><img src="<?php echo e(Storage::url($image->name)); ?>" width="100px" height="100%" alt="">
                        </td>
                        <td><?php echo e($image->created_at); ?></td>
                        <td wire:key="color-variante-<?php echo e($image->id); ?>" class="text-center">
                            <a class="btn-color" href="#"
                                wire:click.prevent="deleteVarianteColor(<?php echo e($image->id); ?>)"
                                wire:loading.attr="disabled"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </table>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php $__env->startPush('script'); ?>
        <script>
            Dropzone.options.myAwesomeDropzoneVariantsColorsEdit = {
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                dictDefaultMessage: "<div>Actualizar color</div> <i class=\"fas fa-camera mt-5\" style=\"font-size: 18pt;\"></i>",
                acceptedFiles: "image/*",
                paramName: "file", // The name that will be used to transfer the file
                maxFilesize: 10, //10MB max, Tambien hemos agregado un validador en el servidor
                init: function() {

                    console.log('init');

                    var myDropzone = this;

                    this.on("sending", function(data, xhr, formData) {
                        formData.append("total_amount", jQuery("#total_amount").val());
                        console.log('sending');
                    });


                },
                complete: function(file) {
                    this.removeFile(file);
                },
                queuecomplete: function() {
                    Livewire.emit('refreshColor');
                },
                accept: function(file, done) {
                    if (file.name == "justinbieber.jpg") {
                        done("Naha, you don't.");
                    } else {
                        done();
                    }
                }
            };
        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product/colors/edit-color-modal.blade.php ENDPATH**/ ?>