<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>3b - Soluciones</title>

    

    <style>
        .logo {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .logo img {
            width: 200px;
        }

        body {
            overflow-y: hidden;
        }
    </style>

</head>

<body>

  <?php echo e($slot); ?>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/layouts/alone.blade.php ENDPATH**/ ?>