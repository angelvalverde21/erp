
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">

            <?php echo e($slot); ?>


            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/sectioncontent.blade.php ENDPATH**/ ?>