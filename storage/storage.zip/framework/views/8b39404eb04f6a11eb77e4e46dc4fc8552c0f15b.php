<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id', 'title' => '', 'footer'=>'', 'size' => '',]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'title' => '', 'footer'=>'', 'size' => '',]); ?>
<?php foreach (array_filter((['id', 'title' => '', 'footer'=>'', 'size' => '',]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div wire:ignore.self class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="<?php echo e($id); ?>Label" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered <?php echo e($size); ?>" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="<?php echo e($id); ?>ModalTitle"><?php echo e($title); ?></h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <?php echo e($slot); ?>


            </div>

            <div class="modal-footer">

                <?php echo e($footer); ?>


                
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
 
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/user/modal.blade.php ENDPATH**/ ?>