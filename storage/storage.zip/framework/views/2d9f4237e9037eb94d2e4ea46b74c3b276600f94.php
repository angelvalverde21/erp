
<section class="content">
    <div class="container-fluid">
            <?php echo e($slot); ?>

    </div>
</section><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/content.blade.php ENDPATH**/ ?>