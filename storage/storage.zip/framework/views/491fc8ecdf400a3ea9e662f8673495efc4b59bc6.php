<div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.products.edit-product.create-album', ['product'=> $product])->html();
} elseif ($_instance->childHasBeenRendered('product-create-album')) {
    $componentId = $_instance->getRenderedChildComponentId('product-create-album');
    $componentTag = $_instance->getRenderedChildComponentTagName('product-create-album');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('product-create-album');
} else {
    $response = \Livewire\Livewire::mount('manage.products.edit-product.create-album', ['product'=> $product]);
    $html = $response->html();
    $_instance->logRenderedChild('product-create-album', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <table id="example" class="table table-striped mt-3">

            <thead>
                <tr>
                    <th>Id</th>
                    <th>Imagen</th>
                    <th>Nombre del album</th>
                    
                    
                    <th>Publicado</th>
                    <th>Qty</th>
                    <th>Modelo</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>

                <?php $__currentLoopData = $product->albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($album->id); ?></td>
                        
                        
                        <td><?php echo e($album->name); ?></td>
                        <td><?php echo e($album->description); ?></td>
                        <td><?php echo e($album->created_at); ?></td>
                        <td><?php echo e($album->images->count()); ?></td>
                        <td><?php echo e($album->modelo->name); ?></td>
                        <td>
                            <div class="d-flex justify-content-center">
                                <a href="<?php echo e(route('manage.products.albums.edit', [$store->nickname, $product->id, $album->id])); ?>"
                                    class="btn btn-success mr-2"><i class="fa-solid fa-pen-to-square"></i></a>
                                
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product/show-albums.blade.php ENDPATH**/ ?>