<div>
    

    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('#btn-add-new-address').on('click', function() {
                    var text = $('#btn-add-new-address').text();
                    if (text === 'Agregar nuevo') {
                        $(this).text('Cancelar');
                        $(this).removeClass('btn-success');
                        $(this).addClass('btn-secondary');
                    } else {
                        $(this).text('Agregar nuevo');
                        $(this).removeClass('btn-secondary');
                        $(this).addClass('btn-success');
                    }
                });

                $('.btn-edit-address').on('click', function() {
                    var text = $(this).text();
                    if (text === 'Editar') {
                        $(this).text('Cancelar');
                    } else {
                        $(this).text('Editar');
                    }
                });
            })
        </script>
    <?php $__env->stopPush(); ?>

    

    <div class="card">
        <div class="card-body">
            <a data-bs-toggle="collapse" id="btn-add-new-address" href="#add-new-address" role="button"
                aria-expanded="false" aria-controls="add-new-address" class="btn btn-success">Agregar nuevo</a>


            <div class="collapse" id="add-new-address">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.addresses.create-address', ['user_id' => $user->id, 'render' => $render])->html();
} elseif ($_instance->childHasBeenRendered('create-addresses-' . $user->id)) {
    $componentId = $_instance->getRenderedChildComponentId('create-addresses-' . $user->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('create-addresses-' . $user->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('create-addresses-' . $user->id);
} else {
    $response = \Livewire\Livewire::mount('components.addresses.create-address', ['user_id' => $user->id, 'render' => $render]);
    $html = $response->html();
    $_instance->logRenderedChild('create-addresses-' . $user->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>

        </div>
    </div>

    

    <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="accordion" id="show-address-all">

            <?php if($loop->first): ?>
                <?php
                    $show = true;
                ?>
            <?php else: ?>
                <?php
                    $show = false;
                ?>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accordion-item','data' => ['id' => 'accordion-'.e($address->id).'','show' => ''.e($show).'','accordionParentId' => 'show-address-all','label' => ''.e($address->name).' - '.e($address->primary).', '.e($address->secondary).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('accordion-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'accordion-'.e($address->id).'','show' => ''.e($show).'','accordionParentId' => 'show-address-all','label' => ''.e($address->name).' - '.e($address->primary).', '.e($address->secondary).'']); ?>

                <li>
                    <h3><?php echo e($address->title); ?></h3>
                </li>
                <li><?php echo e($address->name); ?></li>
                <li>DNI: <?php echo e($address->dni); ?></li>
                <li><?php echo e($address->primary); ?></li>
                <li><?php echo e($address->secondary); ?></li>
                <li><?php echo e($address->references); ?></li>
                <li><?php echo e($address->district->name); ?> -
                    <?php echo e($address->district->province->name); ?> - Dpto.
                    <?php echo e($address->district->province->department->name); ?></li>
                <li>CEL: <?php echo e($address->phone); ?></li>
                <li class='d-block mt-3'>
                    <a data-bs-toggle="collapse" class="btn btn-light btn-edit-address "
                        href="#edit-address-<?php echo e($address->id); ?>" role="button" aria-expanded="false"
                        aria-controls="edit-address-<?php echo e($address->id); ?>">Editar</a>

                    <?php if($address->id == $address_selected): ?>
                    <?php else: ?>
                        <a class="btn btn-light" href="#" role="button"
                            wire:click.prevent="selectAddress('<?php echo e($address->id); ?>')">Seleccionar</a>
                    <?php endif; ?>

                </li>


                
                <div class="collapse" id="edit-address-<?php echo e($address->id); ?>">

                    <?php if($address->id == $address_selected): ?>
                        
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.addresses.edit-address', ['address' => $address->id, 'selected' => 1])->html();
} elseif ($_instance->childHasBeenRendered('edit-address-single-true-' . $address->id)) {
    $componentId = $_instance->getRenderedChildComponentId('edit-address-single-true-' . $address->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('edit-address-single-true-' . $address->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('edit-address-single-true-' . $address->id);
} else {
    $response = \Livewire\Livewire::mount('components.addresses.edit-address', ['address' => $address->id, 'selected' => 1]);
    $html = $response->html();
    $_instance->logRenderedChild('edit-address-single-true-' . $address->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php else: ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.addresses.edit-address', ['address' => $address->id, 'selected' => 0])->html();
} elseif ($_instance->childHasBeenRendered('edit-address-single-false-' . $address->id)) {
    $componentId = $_instance->getRenderedChildComponentId('edit-address-single-false-' . $address->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('edit-address-single-false-' . $address->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('edit-address-single-false-' . $address->id);
} else {
    $response = \Livewire\Livewire::mount('components.addresses.edit-address', ['address' => $address->id, 'selected' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('edit-address-single-false-' . $address->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endif; ?>

                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        </div>

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__env->startPush('script'); ?>
        <script>
            Livewire.on('select_address', function() {
                Swal.fire(
                    'Seleccionado!',
                    'Se ha actualizado la orden',
                    'success'
                )
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/addresses/show-address-all.blade.php ENDPATH**/ ?>