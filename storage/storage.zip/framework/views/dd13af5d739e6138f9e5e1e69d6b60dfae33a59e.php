<div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="card">
            

            <div class="card-header">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.users.create-user-modal', ['store' => $store, 'rol'=> $rol])->html();
} elseif ($_instance->childHasBeenRendered('create-customer-modal')) {
    $componentId = $_instance->getRenderedChildComponentId('create-customer-modal');
    $componentTag = $_instance->getRenderedChildComponentTagName('create-customer-modal');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('create-customer-modal');
} else {
    $response = \Livewire\Livewire::mount('components.users.create-user-modal', ['store' => $store, 'rol'=> $rol]);
    $html = $response->html();
    $_instance->logRenderedChild('create-customer-modal', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive">


                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th class="text-center">Id</th>
                            <th>Nombre</th>
                            <th>DNI</th>
                            <th>Telefono</th>
                            <th>#Compras</th>
                            <th>cliente desde</th>
                            <th>Tipo Cliente</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($user->id); ?></td>

                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->dni); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td></td>
                                <td><?php echo e($user->created_at); ?></td>
                                <td></td>
                                <td>
                                    <div class="d-flex  justify-content-center">
                                        <a href="<?php echo e(route('manage.users.edit', [$store->nickname, $user->id])); ?>"
                                            class="btn btn-success mr-2"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="#" class="btn btn-secondary"><i
                                                class="fa-solid fa-trash"></i></a>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>


            </div>
            <!-- /.card-body -->
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/users/show-users.blade.php ENDPATH**/ ?>