<div class="table-responsive">
    

    


    

    <?php if(count($orders) > 0): ?>

        <table id="example1" class="table table-striped">

            <thead>
                <tr>
                    <th class="text-center">Id</th>
                    <th>Cliente</th>
                    <th>Productos</th>
                    <th>Status</th>
                    <th class="text-center">Asignado</th>
                    <th class="text-center">Empresa</th>
                    <th class="text-center">Status</th>
                    <th>Pago</th>
                    <th>Total</th>
                    <th>Autor</th>
                    <th>Creado</th>
                    <th>Actualizado</th>
                    <th>Editar</th>
                </tr>
            </thead>
            
            <tbody>

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <tr <?php if(!$order->is_active): ?> class="bg-danger" <?php endif; ?>
                        <?php if($order->is_delivered()): ?> style="background: #E2FBDF;" <?php endif; ?>>


                        <?php if($order->is_pay()): ?>
                            <td class="text-center" style="background: #E2FBDF;">
                                <a href="<?php echo e(route('manage.orders.edit', [$store->nickname, $order->id])); ?>"
                                    class="btn btn-success"><i class="fa-solid fa-pen-to-square"></i></a>
                                <p class="mt-1">#<?php echo e($order->id); ?></p>

                            </td>
                        <?php else: ?>
                            <td class="text-center">
                                <a href="<?php echo e(route('manage.orders.edit', [$store->nickname, $order->id])); ?>"
                                    class="btn btn-secondary"><i class="fa-solid fa-pen-to-square"></i></a>
                                <p class="mt-1">#<?php echo e($order->id); ?></p>

                            </td>
                        <?php endif; ?>

                        <td class="">
                            <h6><?php echo e(strtoupper($order->buyer->name)); ?></h6>
                            

                            <li>DNI: <?php echo e($order->address->dni); ?></li>
                            <li><?php echo e($order->address->primary); ?></li>
                            <li><?php echo e($order->address->secondary); ?></li>
                            <li>References: </li>
                            <li><?php echo e($order->address->references); ?></li>
                            <li><strong><?php echo e($order->address->district->name); ?></strong> -
                                <?php echo e($order->address->district->province->name); ?> -
                                <?php echo e($order->address->district->province->department->name); ?></li>
                            <li><?php echo e($order->delivery_time_start); ?> Hasta <?php echo e($order->delivery_time_end); ?>

                            </li>
                            <li><?php echo e($order->address->phone); ?></li>

                            <li class="d-flex flex-row">
                                <a class="btn btn-secondary d-flex align-items-center" style="font-size: 10pt;"
                                    href="tel:+51<?php echo e($order->address->phone); ?>">
                                    <i class="fa-solid fa-square-phone"></i>
                                    <span class="mx-1"><?php echo e($order->address->phone); ?></span>
                                </a>
                                <a class="btn btn-success mx-2" style="font-size: 10pt;" target="_blank"
                                    href="https://api.whatsapp.com/send?phone=51<?php echo e($order->address->phone); ?>&text=<?php echo e(urlencode('Hola buen dia, Somos ' . Str::upper($store->nickname) . ' Express Courier, te informamos que tu pedido sera entregado hoy, en el horario cordinado, tu codigo de pedido es: #')); ?><?php echo e($order->id); ?>">Whatsp</a>

                                <a class="btn btn-primary" style="font-size: 10pt;" target="_blank"
                                    href="https://www.google.com/maps/search/<?php echo e($order->address->primary); ?>,<?php echo e($order->address->district->province->name); ?>"><i
                                        class="fa-solid fa-diamond-turn-right"></i><span class="mx-1">Ruta</span></a>
                            </li>

                        </td>

                        <td class="text-center">
                            <?php if($order->is_pay()): ?>
                                <span class="text-success" style="font-size: 1.5rem"><i
                                        class="fa-solid fa-sack-dollar"></i></span>
                            <?php else: ?>
                                <span class="text-secondary" style="font-size: 1.5rem"><i
                                        class="fa-solid fa-sack-dollar"></i></span>
                            <?php endif; ?>
                        </td>

                        <td>
                            

                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i = 0; $i < $item->quantity; $i++): ?>
                                    <?php if(isset($item->content->image)): ?>
                                        <a href="<?php echo e(Storage::url($item->content->image)); ?>"
                                            data-lightbox="show-images-preview-<?php echo e($order->id); ?>"
                                            data-title="TALLA: <?php echo e($item->content->talla_impresa); ?>">
                                            <img loading="lazy" style="height: 125px"
                                                src="<?php echo e(Storage::url($item->content->image)); ?>" alt="">
                                            (<?php echo e($item->content->talla_impresa); ?>)
                                        </a>
                                    <?php else: ?>
                                        Sin imagen
                                    <?php endif; ?>
                                <?php endfor; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td class="text-center">
                            <?php if($order->delivery_man): ?>
                                <?php echo e($order->delivery_man->name); ?>

                            <?php else: ?>
                                No se ha seleccionado el personal de entrega
                            <?php endif; ?>

                        </td>
                        <td class="text-center">
                            <?php switch($order->delivery_method_id):
                                case (1): ?>
                                    <img src="<?php echo e($order->carrier_address->user->getOption('logo_profile')); ?>" width="100px"
                                        alt="">
                                <?php break; ?>

                                <?php case (2): ?>
                                    RECOJO EN TIENDA
                                <?php break; ?>

                                <?php default: ?>
                            <?php endswitch; ?>
                        </td>
                        <td class="text-center">

                            <p><?php echo e($order->print_status()); ?></p>
                            
                            

                        </td>

                        <td><?php echo e($order->total_amount); ?></td>

                        <td><?php echo e($order->total_amount); ?></td>
                        <td><?php echo e($order->seller->name); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td><?php echo e($order->updated_at); ?></td>
                        <td>
                            <a href="#" wire:click="cancelOrder( <?php echo e($order); ?> )" class="btn btn-danger"><i
                                    class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    <?php else: ?>
        No hay registros disponibles
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/_show-orders-table.blade.php ENDPATH**/ ?>