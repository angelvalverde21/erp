
<div>
    



    <div class="card">

        <div class="card-header">
            <a class="btn btn-success btn-add-empresa float-right" data-toggle="collapse" href="#collapse-create-carrier"
                role="button" aria-expanded="false" aria-controls="collapse-create-carrier">
                Agregar courier
            </a>
        </div>

        <div class="collapse" id="collapse-create-carrier">
            <div class="card-body">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.carriers.create-carrier', ['user_id' => ''])->html();
} elseif ($_instance->childHasBeenRendered('create-carrier')) {
    $componentId = $_instance->getRenderedChildComponentId('create-carrier');
    $componentTag = $_instance->getRenderedChildComponentTagName('create-carrier');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('create-carrier');
} else {
    $response = \Livewire\Livewire::mount('components.carriers.create-carrier', ['user_id' => '']);
    $html = $response->html();
    $_instance->logRenderedChild('create-carrier', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>


    <div class="accordion" id="accordionShowCarrier">

        
        <?php $__currentLoopData = $carriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.accordion-item','data' => ['id' => 'item-carrier-'.e($carrier->id).'','label' => ''.e($carrier->name).'','icon' => 'fa-solid fa-truck-fast','accordionParentId' => 'accordionShowCarrier']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('accordion-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'item-carrier-'.e($carrier->id).'','label' => ''.e($carrier->name).'','icon' => 'fa-solid fa-truck-fast','accordion_parent_id' => 'accordionShowCarrier']); ?>

                <div class="table-responsive">
                    <table class="table table-transportista mx-0 mb-3">

                        

                        <?php $__currentLoopData = $carrier->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <?php if($order->id > 0): ?>
                                    <td><a class="btn btn-secondary" href="#" role="button"
                                            wire:click.prevent="selectAddress('<?php echo e($office->id); ?>')">Seleccionar</a>
                                    </td>
                                <?php endif; ?>

                                <td><?php echo e($office->title); ?></td>
                                <td><?php echo e($office->name); ?></td>
                                <td><?php echo e($office->primary); ?> <?php echo e($office->secondary); ?></td>
                                <td><?php echo e($office->references); ?></td>
                                <td><?php echo e($office->district->name); ?></td>
                                <td>
                                    <a href="#collapse-edit-carrier-<?php echo e($office->id); ?>"
                                        class="btn btn-secondary float-end" data-toggle="collapse" role="button"
                                        aria-expanded="false" aria-controlxs="collapseExample">Editar
                                    </a>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="7">

                                    <div class="collapse mt-4" id="collapse-edit-carrier-<?php echo e($office->id); ?>">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.carriers.edit-office-carrier', ['address' => $office->id])->html();
} elseif ($_instance->childHasBeenRendered('edit-office-carrier-' . $office->id)) {
    $componentId = $_instance->getRenderedChildComponentId('edit-office-carrier-' . $office->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('edit-office-carrier-' . $office->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('edit-office-carrier-' . $office->id);
} else {
    $response = \Livewire\Livewire::mount('components.carriers.edit-office-carrier', ['address' => $office->id]);
    $html = $response->html();
    $_instance->logRenderedChild('edit-office-carrier-' . $office->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>

                

                <div class="controls d-flex justify-content-between">
                    <a class="btn btn-primary btn-agregar-office" data-toggle="collapse"
                        href="#collapse-carrier-<?php echo e($carrier->id); ?>" role="button" aria-expanded="false"
                        aria-controls="collapseExample"><i class="fa-solid fa-circle-plus mr-2"></i>
                        Agregar Oficina
                    </a>

                    </a>
                    
                    <a href="<?php echo e(route('manage.couriers.edit', [$order->store->id, $carrier->id])); ?>" class="btn btn-success"><i class="fa-solid fa-gear mr-2"></i>
                        Editar Courier
                    </a>
                </div>

                <div class="collapse mt-4" id="collapse-carrier-<?php echo e($carrier->id); ?>">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.carriers.create-office-carrier', ['user_id' => $carrier->id])->html();
} elseif ($_instance->childHasBeenRendered('create-office-carrier-' . $carrier->id)) {
    $componentId = $_instance->getRenderedChildComponentId('create-office-carrier-' . $carrier->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('create-office-carrier-' . $carrier->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('create-office-carrier-' . $carrier->id);
} else {
    $response = \Livewire\Livewire::mount('components.carriers.create-office-carrier', ['user_id' => $carrier->id]);
    $html = $response->html();
    $_instance->logRenderedChild('create-office-carrier-' . $carrier->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                


             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {

                function changeTextBtn(selector, textInit, BtnClass) {

                    $(selector).on('click', function() {
                        text = $(this).text().trimStart().trimEnd();

                        if (text == textInit) {
                            console.log(textInit);

                            $(this).text('Cancelar');
                            $(this).removeClass(BtnClass);
                            $(this).addClass('btn-secondary');
                        } else {
                            console.log('x');

                            $(this).text(textInit);
                            $(this).removeClass('btn-secondary');
                            $(this).addClass(BtnClass);
                        }

                    });

                }

                changeTextBtn('.btn-agregar-office', 'Agregar Oficina', 'btn-primary');
                changeTextBtn('.btn-add-empresa', 'Agregar courier', 'btn-success');

            });
        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/carriers/show-carrier-all.blade.php ENDPATH**/ ?>