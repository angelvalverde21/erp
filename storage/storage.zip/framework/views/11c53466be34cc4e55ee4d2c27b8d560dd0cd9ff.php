<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['icon'=>'','alert']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['icon'=>'','alert']); ?>
<?php foreach (array_filter((['icon'=>'','alert']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="alert alert-<?php echo e($alert); ?>" role="alert">
    <div>
        <?php if($icon != ""): ?>
            <i class="<?php echo e($icon); ?> mr-2"></i>
        <?php endif; ?>
        <?php echo e($slot); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

</div><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/alert.blade.php ENDPATH**/ ?>