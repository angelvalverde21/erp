<div>

    <ul class="list-group mb-3">

        <li class="list-group-item  list-group-item-dark d-flex justify-content-between align-items-center">
            <span><h6><i class="fa-solid fa-comments-dollar me-2"></i> Gastos de envio</h6></span>
            <div class="controls">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.button-open-modal','data' => ['target' => '#editCarrierOrderDetails','mr' => '0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#editCarrierOrderDetails','mr' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </li>

        <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
                <h6 class="my-0">Costo de envio</h6>
                <small class="text-muted">Costo que ha pagodo el cliente</small>
            </div>
            <span class="text-muted">S/. <?php echo e($order->shipping_cost_buyer); ?></span>
        </li>

        <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
                <h6 class="my-0">Translado</h6>
                <small class="text-muted">Pasajes y taxis para envio</small>
            </div>
            <span class="text-muted">S/. <?php echo e($order->shipping_cost_to_carrier); ?></span>
        </li>

        <li class="list-group-item d-flex justify-content-between">
            <div>
                <h6 class="my-0">Gasto envio</h6>
                <small class="text-muted">Costo que cobra la agencia</small>
            </div>
            <span class="text-muted">S/. <?php echo e($order->shipping_cost_carrier); ?></span>
        </li>

        <li class="list-group-item d-flex justify-content-between">
            <div>
                
            </div>
            <div>
                <span>S/. <?php echo e($order->shipping_cost_buyer - $order->shipping_cost_to_carrier - $order->shipping_cost_carrier); ?></span>
            </div>
        </li>

    </ul>

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => 'Costos de:','id' => 'editCarrierOrderDetails','size' => 'modal-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Costos de:','id' => 'editCarrierOrderDetails','size' => 'modal-lg']); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.modal-carrier-details', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('modal-carrier-details-' . $order->id)) {
    $componentId = $_instance->getRenderedChildComponentId('modal-carrier-details-' . $order->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('modal-carrier-details-' . $order->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('modal-carrier-details-' . $order->id);
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.modal-carrier-details', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('modal-carrier-details-' . $order->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

         <?php $__env->slot('footer', null, []); ?> 

         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/card-shipping-cost.blade.php ENDPATH**/ ?>