<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.select','data' => ['id' => 'payment_method_id','label' => 'Cliente indica que pagara con','wirevalue' => 'order.payment_method_id','icon' => 'fa-solid fa-money-bill-1-wave','wirechange' => 'saveSelected()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'payment_method_id','label' => 'Cliente indica que pagara con','wirevalue' => 'order.payment_method_id','icon' => 'fa-solid fa-money-bill-1-wave','wirechange' => 'saveSelected()']); ?>

    <?php $__currentLoopData = paymentMethods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($paymentMethod->id); ?>"> <?php echo e($paymentMethod->name); ?></option>

        <?php $__currentLoopData = $paymentMethod->paymentMethodChildrens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethodChildren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('livewire.manage.orders.edit-order._navbar-pay-method-child', [
                'parent_name' => $paymentMethod->name,
                'child' => $paymentMethodChildren,
                'separador' => '--',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
`
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/_navbar-pay-method.blade.php ENDPATH**/ ?>