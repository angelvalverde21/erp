<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice # <?php echo e($order->id); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<style>
    ul {
        margin: 0;
        padding: 0;
    }

    li {
        list-style: none;
    }
</style>

<body style="font-family: Arial, Helvetica, sans-serif">


    <div class="container"> 

        <div class="header d-flex justify-content-between">
            <div class="logo">
                <?php if($order->store->getOption('upload_logo_invoice')): ?>
                    <img width="250px" class="logo py-2" src="<?php echo e($order->store->getOption('upload_logo_invoice')); ?>"
                        alt="">
                <?php else: ?>
                    <h1 class="my-3">SU LOGO AQUI</h1>
                <?php endif; ?>
            </div>

            <div class="info-right text-end">
                <h4>ORDEN DE COMPRA #COD: <?php echo e($order->id); ?></h4>
                <h6> Aquarella Ropa y Accesorios</h6>
                <h6> LIMA - PERU</h6>
            </div>
        </div>

        <div class="consignatario">

            <div class="p-2" style="background-color: #E1E1E1; font-size: 1.25rem">
                <strong>RECIBE: <?php echo e(Str::upper($order->address->name)); ?></strong>
            </div>

            <ul class="py-1 px-3">
                <li>DNI: <?php echo e($order->address->dni); ?></li>
                <li>TELEFONO: <?php echo e($order->address->phone); ?></li>
                <li>DIRECCION: <?php echo e($order->address->primary); ?></li>
                <li>
                    <?php echo e($order->address->district->name); ?> -
                    <?php echo e($order->address->district->province->name); ?> -
                    <?php echo e($order->address->district->province->department->name); ?>

                </li>
            </ul>

        </div>

        <div class="delivery-date">
            <div class="p-2" style="background-color: #E1E1E1; font-size: 1.25rem">
                <strong>FECHA Y HORA DE ENTREGA</strong>
            </div>

            <div class="content-delivery-details d-flex justify-content-between align-items-center">
                <ul class="py-1 px-3">
                    <li>FECHA ENTREGA: <?php echo e($order->delivery_date); ?></li>
                    <li>MEDIO DE PAGO: <?php echo e($order->payment_method); ?></li>
                    <li>HORA DE ENTREGA: <?php echo e($order->delivery_time_start); ?> - <?php echo e($order->delivery_time_end); ?></li>
                    <li>OBSERVACIONES HORARIO: <?php echo e($order->observations_delivery); ?></li>
                </ul>

                <div class="barcode">
                    <div class="show">
                        <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($order->id, 'C39')); ?>" alt="barcode"
                            height="30" width="300" />
                    </div>
                    <div class="code text-center">
                        <small>#<?php echo e($order->id); ?></small>
                    </div>

                </div>

            </div>

        </div>

        <div class="table">
            <table class="table table-striped">
                <thead>
                    <tr class="bg bg-secondary text-white">
                        <td>COD</td>
                        <td>QTY</td>
                        <td>DESCRIPCION</td>
                        <td>TALLA</td>
                        <td class="text-center">PRECIO</td>
                        <td class="text-center">SUB TOTAL</td>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <td><?php echo e($item->content->talla_impresa); ?></td>
                            <td class="text-center">S/. <?php echo e($item->content->price); ?></td>
                            <td class="text-center">S/. <?php echo e($item->quantity * $item->content->price); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

                <tfoot>

                    <tr>
                        <td colspan="6"><?php echo e($order->amountToString()); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-end py-3"><strong>SUBTOTAL: </strong></td>
                        <td class="text-center py-3">S/. <?php echo e($order->sub_total); ?></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-end py-3"><strong>DESCUENTOS: </strong></td>
                        <td class="text-center py-3">S/. <?php echo e($order->descuentos); ?></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-end py-3"><strong>ENVIO: </strong></td>
                        <td class="text-center py-3">S/. <?php echo e($order->shipping_cost_buyer); ?></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="text-end py-3"><strong>TOTAL: </strong></td>
                        <td class="text-center py-3" style="font-size: 2rem">S/.
                            <strong><?php echo e($order->total_amount); ?></strong></td>
                    </tr>


                </tfoot>
            </table>

            
        </div>


    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/print/invoice.blade.php ENDPATH**/ ?>