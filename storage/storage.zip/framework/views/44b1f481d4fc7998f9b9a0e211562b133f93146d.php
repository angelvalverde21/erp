<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voucher de venta</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
        body {
            border: 1px solid #ccc;
            margin: 0px;
            font-family: sans-serif;
            font-size: 10pt;
            padding: 0 10px;
        }

        @page {
            margin: 0px;
            padding: 0px;
        }

        .logo {
            width: auto;
            width: 180px;
            max-height: 60px;
            margin: 10 0 10px 0;
            border: 0px solid #ccc
        }

        .header {
            text-align: center;
            position: relative;
        }

        .header h1 {
            margin: 0;
            padding: 0;
            font-size: 12pt;
            border: 0px solid #ccc
        }

        .body-content {
            margin: 10px 0 0 0;
            border: 0px solid #ccc
        }

        .barcode {
            text-align: center;
        }

        .name {
            margin-bottom: 10px;
            font-size: 11pt;
            text-align: center;
            font-weight: bold;
        }

        li {
            list-style: none;
            margin: 0;
            padding;
            0;
        }

        ul {
            margin: 0;
            padding;
            0;
        }

        .linea-separador {
            margin: 10px 15px 0 15px;
            height: 2px;
            border-color: #000000;
        }

        /* .qr {
            margin: 0;
            width: 30%;
            border: 0px solid #ccc;
            float: left;
        }

        .resumen {
            width: 60%;
            border: 0px solid #ccc;
            float: right;
            padding: 0 20px 0 0;
        } */

        .resumen li {
            text-align: right;
        }

        .status-pago {
            text-align: center;
            font-weight: bold;
            border: 0px solid #ccc;
        }

        .content-header {
            width: 100%;
            display: inline-block;
            border: 0px solid red;
            height: 110px;
        }

        .content-items {
            width: 100%;
            display: inline-block;
            border: 0px solid red;
        }

        .pagado {
            position: absolute;
            top: 200px;
            left: 75px;
            opacity: 0.5;
        }

        .content-qr {
            float: left;
        }

        .resumen {
            float: right;
        }
    </style>
</head>

<body>

    <div class="pagado">
        <?php if($order->is_pay()): ?>
            <img class="px-1 pt-1" src="<?php echo e(asset(Storage::url('orders/pagado.png'))); ?>" height="250px" alt="">
        <?php endif; ?>
    </div>
    <div class="header">

        

        <?php if($order->store->getOption('upload_logo_invoice')): ?>
            <img class="logo" src="<?php echo e($order->store->getOption('upload_logo_invoice')); ?>" alt="">
        <?php else: ?>
            <h1 class="my-5">SU LOGO AQUI</h1>
        <?php endif; ?>


        <h1 class="name">ORDEN DE COMPRA: #<?php echo e($order->id); ?></h1>
        
        <hr class="linea-separador">
    </div>

    <div class="body-content">

        <div class="barcode">
            
            <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG('2561465165024', 'C39')); ?>" alt="barcode"
                height="40" width="300" />

            <small>2561465165024</small>
        </div>

        <style>
            .ficha {
                margin: 0 15px;
            }
        </style>

        <div class="name"><?php echo e(strtoupper($order->address->name)); ?></div>

        <div class="ficha" style="margin: 0: padding: 0">
            <li><span class="fw-bold">DNI:</span> <?php echo e($order->address->dni); ?></li>
            <li><span class="fw-bold">TELEFONO:</span> <?php echo e($order->address->phone); ?></li>
            <li><span class="fw-bold">DIRECCION:</span> <?php echo e(strtoupper($order->address->primary)); ?></li>
            <li><?php echo e($order->address->secondary); ?></li>
            <li><?php echo e($order->address->district->name); ?> -
                <?php echo e($order->address->district->province->name); ?> -
                <?php echo e($order->address->district->province->department->name); ?></li>
            <li><span class="fw-bold">REFERENCIA:</span> <?php echo e(strtoupper($order->address->references)); ?></li>


            <li class=""><span class="fw-bold">FECHA ENVIO:</span> <?php echo e($order->delivery_date); ?></li>
            
            </ul>
        </div>

        <div class="content-items pt-3 text-center">
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="px-1 pt-1" src="<?php echo e(asset(Storage::url($item->content->image))); ?>" height="85px"
                    alt="">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <hr class="linea-separador">

        <div class="content-header pt-2">

            <div class="content-qr">

                <?php if($order->store->getOption('code_yape')): ?>
                    <div class="qr text-center w-100">
                        <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($order->store->getOption('code_yape'), 'QRCODE')); ?>"
                            alt="barcode" height="100" width="100" />
                    </div>
                    <div class="w-100 text-center"> Yape </div>
                <?php else: ?>
                    <div class="logo_temp p-3">
                        <img src="<?php echo e(asset(Storage::url('upload_qr_temp.jpg'))); ?>" alt="barcode" height="100"
                            width="100" />
                    </div>

                    
                <?php endif; ?>


                
            </div>

            <div class="resumen">
                <li>SUBTOTAL: S/. <?php echo e($order->sub_total); ?></li>
                <?php if($order->descuentos > 0): ?>
                    <li>DESCUENTOS: S/. <?php echo e($order->descuentos); ?></li>
                <?php endif; ?>

                <?php if($order->shipping_cost_buyer > 0): ?>
                    <li>ENVIO <?php if($order->is_contra_entrega()): ?>
                            (Motorizado)
                        <?php endif; ?>: S/. <?php echo e($order->shipping_cost_buyer); ?></li>
                <?php else: ?>
                    <li>ENVIO: GRATIS</li>
                <?php endif; ?>
                <li>------------------------------------</li>
                <li><strong style="font-size: 14pt">TOTAL: S/. <?php echo e($order->total_amount); ?></strong></li>
            </div>


        </div>

        <hr>
        <div class="transporte ">


            <?php switch($order->delivery_method_id):
                case (1): ?>
                    <div class="text-center">
                        Se transportara por: <?php echo e($order->carrier_address->name); ?>

                    </div>
                    <div class="logo w-100 text-center">
                        <img src="<?php echo e($order->carrier_address->user->getOption('logo_profile')); ?>" height="50px">
                    </div>
                <?php break; ?>

                <?php case (2): ?>
                    <h1 class="w-100 text-center">RECOJO EN TIENDA</h1>
                <?php break; ?>

            <?php endswitch; ?>


        </div>

        <?php if(!$order->is_pay()): ?>

            <hr class="linea-separador my-3">

            <div class="status-pago">
                <h1>PENDIENTE DE PAGO</h1>
                <?php if($order->is_contra_entrega()): ?>
                    <h2>(CONTRA ENTREGA)</h2>
                <?php endif; ?>

            </div>

        <?php endif; ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/print/voucher.blade.php ENDPATH**/ ?>