<option value="<?php echo e($child->id); ?>"><?php echo e($separador); ?> <?php echo e($child->name); ?></option>
    
<?php if($child->paymentMethods): ?>
        <?php $__currentLoopData = $child->paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childPaymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php echo $__env->make('livewire.manage.orders.edit-order._navbar-pay-method-child', ['child' => $childPaymentMethod, 'separador'=>  $separador.$separador], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order/_navbar-pay-method-child.blade.php ENDPATH**/ ?>