<div>

    

    <ul class="list-group mb-3">
        
        <li class="list-group-item  list-group-item-dark d-flex justify-content-between align-items-center">
            <span>
                <h6><i class="fa-solid fa-user me-2"></i> Direccion de envio</h6>
            </span>
            <div class="controls">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.button-open-modal','data' => ['target' => '#show-all-address-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.button-open-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#show-all-address-modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </li>
        <li class="list-group-item">
            <h5><?php echo e($address->name); ?></h5>
        </li>
        <li class="list-group-item">DNI: <?php echo e($address->dni); ?></li>
        <li class="list-group-item"><?php echo e($address->primary); ?></li>

        <?php if($address->secondary != ''): ?>
            <li class="list-group-item"><?php echo e($address->secondary); ?></li>
        <?php endif; ?>
        <?php if($address->references != ''): ?>
            <li class="list-group-item"><?php echo e($address->references); ?></li>
        <?php endif; ?>
        <li class="list-group-item"><?php echo e($address->district->name); ?> -
            <?php echo e($address->district->province->name); ?> - Dpto.
            <?php echo e($address->district->province->department->name); ?></li>
        <li class="list-group-item">CEL: <?php echo e($address->phone); ?></li>
    </ul>

    


    <!-- Modal content de Address All-->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'show-all-address-modal','title' => 'Agregar o editar direccion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'show-all-address-modal','title' => 'Agregar o editar direccion']); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.addresses.show-address-all', ['user' => $address->user_id, 'model_refer' => $this->model_refer, 'model_refer_id' => $this->model_refer_id])->html();
} elseif ($_instance->childHasBeenRendered('show-addresses-all-' . $address->user_id)) {
    $componentId = $_instance->getRenderedChildComponentId('show-addresses-all-' . $address->user_id);
    $componentTag = $_instance->getRenderedChildComponentTagName('show-addresses-all-' . $address->user_id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('show-addresses-all-' . $address->user_id);
} else {
    $response = \Livewire\Livewire::mount('components.addresses.show-address-all', ['user' => $address->user_id, 'model_refer' => $this->model_refer, 'model_refer_id' => $this->model_refer_id]);
    $html = $response->html();
    $_instance->logRenderedChild('show-addresses-all-' . $address->user_id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <script>
        window.addEventListener('closeModal', event => {
            $('#show-all-address-modal').modal('hide');
            console.log('modal cerrado');
        })
    </script>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/addresses/show-address.blade.php ENDPATH**/ ?>