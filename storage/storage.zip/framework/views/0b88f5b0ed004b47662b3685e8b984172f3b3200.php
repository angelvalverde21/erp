<div>
    

    <div class="card bg-">
        <div class="card-body py-0">
            <div class="table-responsive">
                <table class="table">
                    <thead class="bg-secondary">
                        <tr>
                            <td class="text-center">ID</td>
                            <td class="text-center">QTY</td>
                            <td class="text-center">Talla solicitada</td>
                            <td class="text-center">Imagen</td>
                            <td>Descripcion</td>
                            <td>Precio</td>
                            <td>Final</td>
                            <td>Stock</td>
                            <td>Mensaje</td>
                            <td class="text-center">Eliminar</td>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">

                                    <!-- Button trigger modal para editar los item de la orden -->
                                    <a style="font-size: 15pt;" wire:ignore.self
                                        wire:click.prevent="editItem(<?php echo e($item); ?>)" href="#"><i
                                            class="fa-solid fa-pen-to-square" data-toggle="modal"
                                            data-target="#editItem"></i></a> <?php echo e($item->id); ?>

                                    <!-- fin de Button trigger modal para editar los item de la orden -->

                                </td>
                                <td class="text-center"><?php echo e($item->quantity); ?></td>

                                <td class="text-center"><?php echo e($item->content->talla_impresa); ?></td>
                                

                                <?php if(isset($item->content->image)): ?>
                                    
                                    <td class="text-center">
                                        <?php for($i=0; $i<$item->quantity; $i++): ?>
                                            <a href="<?php echo e(Storage::url($item->content->image)); ?>"
                                                data-lightbox="show-images-preview"
                                                data-title="Click the right half of the image to move forward.">
                                                <img src="<?php echo e(Storage::url($item->content->image)); ?>" height="125px"
                                                    alt="">
                                            </a>
                                        <?php endfor; ?>
                                    </td>
                                <?php else: ?>
                                    <td class="text-center">Sin imagen</td>
                                <?php endif; ?>


                                <td>

                                    <?php if(isset($item->content->product_id)): ?>
                                        <a
                                            href="<?php echo e(route('manage.products.edit', [$store->nickname, $item->content->product_id])); ?>"><?php echo e($item->description); ?></a>
                                    <?php else: ?>
                                <td class="text-center">Sin url</td>
                        <?php endif; ?>



                        <div class="content-stock">

                            <div class="display-stock">

                                
                                <?php if($item->stocks->count()): ?>
                                    <?php $__currentLoopData = $item->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <table>
                                            <tr>
                                                <td>Stock asignado</td>
                                                <td>00000<?php echo e($stock->id); ?></td>
                                                <td>STATUS : <?php echo e($stock->status); ?></td>
                                                <td><?php echo e($stock->stockable->size->name); ?></td>
                                            </tr>
                                        </table>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.items.add-stock-item', ['item' => $item])->html();
} elseif ($_instance->childHasBeenRendered('add-stock-item-' . $item)) {
    $componentId = $_instance->getRenderedChildComponentId('add-stock-item-' . $item);
    $componentTag = $_instance->getRenderedChildComponentTagName('add-stock-item-' . $item);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('add-stock-item-' . $item);
} else {
    $response = \Livewire\Livewire::mount('components.items.add-stock-item', ['item' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild('add-stock-item-' . $item, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                <?php endif; ?>

                            </div>

                        </div>

                        </td>

                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->precio_final); ?></td>

                        
                        <td>

                            <?php if($item->quantity > 0): ?>
                                <a href="#" class="btn btn-success"><i class="fa-solid fa-circle-check"></i></a>
                            <?php elseif($item->quantity_oversale > 0): ?>
                                <a href="#" class="btn btn-danger"><i
                                        class="fa-solid fa-triangle-exclamation"></i></a>
                                <span class="badge bg-secondary">Sin stock</span>
                            <?php endif; ?>

                        </td>

                        <td>
                            <?php if($item->quantity_oversale > 0 && stockColorSizeId($item->content->color_size_id) >= $item->quantity_oversale): ?>
                                <a href="#" class="btn btn-light"
                                    wire:click="corregirStock(<?php echo e($item->id); ?>)">Corregir</a>
                            <?php else: ?>
                                <?php if(isset($item->content->color_size_id)): ?>
                                    Quedan <?php echo e(stockColorSizeId($item->content->color_size_id)); ?>

                                <?php else: ?>
                                    Aun se ha asignado talla
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>

                        <td class="text-center">

                            <?php if($order->is_active): ?>
                                <div class="" wire:key="item-<?php echo e($item->id); ?>">
                                    <a href="#" wire:click.prevent="deleteItem(<?php echo e($item->id); ?>)"
                                        wire:loading.attr="disabled" wire:target="deleteItem(<?php echo e($item->id); ?>)"
                                        style="font-size: 20pt;"><i class="fa-solid fa-trash"></i></a>
                                </div>
                            <?php endif; ?>

                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>

        <div class="card-footer">
            <?php if($order->is_active): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.items.add-item', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('add-item-' . $order->id)) {
    $componentId = $_instance->getRenderedChildComponentId('add-item-' . $order->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('add-item-' . $order->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('add-item-' . $order->id);
} else {
    $response = \Livewire\Livewire::mount('components.items.add-item', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('add-item-' . $order->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php else: ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal para editar los items -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.modal','data' => ['title' => 'Editar Item','id' => 'editItem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Editar Item','id' => 'editItem']); ?>

        <div class="row">
            <div class="col-lg-12 col-12">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.input','data' => ['type' => 'text','wirevalue' => 'item.description','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wirevalue' => 'item.description','error' => 'Este campo es requerido']); ?>
                    Descripcion
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>

            <div class="col-lg-6 col-6">


                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['wirevalue' => 'item.content.talla_impresa','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wirevalue' => 'item.content.talla_impresa','error' => 'Este campo es requerido']); ?>
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="ESTANDAR">ESTANDAR</option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                
            </div>

            <div class="col-lg-6 col-6">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.input','data' => ['type' => 'text','wirevalue' => 'item.content.price','texticon' => 'S/.','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wirevalue' => 'item.content.price','texticon' => 'S/.','error' => 'Este campo es requerido']); ?>
                    Precio
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>

         <?php $__env->slot('footer', null, []); ?> 
            <button type="button" data-dismiss="modal" class="btn btn-info" wire:loading.attr="disabled"
                wire.target="save" wire:click="saveEditItem"><i class="fa-solid fa-floppy-disk mr-1"></i> Guardar
            </button>
         <?php $__env->endSlot(); ?>

        
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/items/show-item-all.blade.php ENDPATH**/ ?>