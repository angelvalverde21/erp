<div>
    

    

    <?php if($posts->count() > 0): ?>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('web.home.show-posts', ['post' => $post])->html();
} elseif ($_instance->childHasBeenRendered('post' . $post->id)) {
    $componentId = $_instance->getRenderedChildComponentId('post' . $post->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('post' . $post->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('post' . $post->id);
} else {
    $response = \Livewire\Livewire::mount('web.home.show-posts', ['post' => $post]);
    $html = $response->html();
    $_instance->logRenderedChild('post' . $post->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    <?php else: ?>
        No se encontro resultados
    <?php endif; ?>

    <?php $__env->startPush('script'); ?>
        <script>
            Livewire.on('glider', function(id) {
                new Glider(document.querySelector('.glider-' + id), {

                    slidesToShow: 3,
                    slidesToScroll: 1,
                    draggable: true,
                    dots: '.dots-' + id,
                    arrows: {
                        prev: '.glider-prev-' + id,
                        next: '.glider-next-' + id
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/web/home.blade.php ENDPATH**/ ?>