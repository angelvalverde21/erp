<div>
    

    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#add-stock-item-<?php echo e($item->id); ?>">
        <i class="fa-solid fa fa-square-plus mr-2"></i>Asignar stock al item
    </button>

    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="add-stock-item-<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Asignar Stock</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">

                    <div class="row">

                        <div class="col-lg-12 col">

                            <div class="mb-3">

                                <div class="">
                                    <ul>

                                            <table class="table">

                                                <thead>
                                                    <tr class="fw-bold">
                                                        <td class="text-center">#ID</td>
                                                        <td class="text-center">Color</td>
                                                        <td></td>
                                                        <td>Qty</td>
                                                        
                                                        <td>Eliminar</td>
                                                    </tr>
                                                </thead>

                                                <tbody>

                                                    

                                                    

                                                        
                                                        <?php $__currentLoopData = $color->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="text-center">

                                                                <?php if($loop->first): ?>
                                                                    <td class="text-center"
                                                                        rowspan="<?php echo e($loop->count); ?>">
                                                                        <?php echo e($color->id); ?></td>

                                                                    

                                                                    

                                                                    

                                                                    <td rowspan="<?php echo e($loop->count); ?>">
                                                                        <img src="<?php echo e($color->image->name); ?>" height="100px" alt=""></td>
                                                                <?php endif; ?>

                                                                

                                                                

                                                                

                                                                
                                                                <td class="py-3">

                                                                    <?php echo e($size->name); ?>

                                                                    


                                                                </td>

                                                                

                                                                

                                                                

                                                                

                                                                

                                                                <td class="text-center">


                                                                    <div class="input-group">
                                                                        
                                                                        <?php if($size->pivot->quantity): ?>

                                                                            <select name="" id="" wire:model="quantity.<?php echo e($size->pivot->id); ?>" class="form-control">

                                                                                <option value="0" selected>0</option>

                                                                                <?php for($i = 1; $i <= $size->pivot->quantity; $i++): ?>
                                                                                    <option  value="<?php echo e($i); ?>"> <?php echo e($i); ?> (Disponibles)</option>
                                                                                <?php endfor; ?>

                                                                            </select>

                                                                        <?php else: ?>
                                                                        
                                                                        <?php endif; ?>


                                                                    </div>

                                                                </td>

                                                                
                                                                
                                                                
                                                                
                                                                

                                                                

                                                                
                                                                    
                                                                    

                                                                    
                                                                

                                                                


                                                                

                                                                
                                                                <td class="text-center">
                                                                    <?php if(isset($quantity[$size->pivot->id]) && $quantity[$size->pivot->id] > 0): ?>
                                                                        <a href="#"
                                                                            wire:click.prevent="separarOrAsignar(<?php echo e($size->pivot->id); ?>)"
                                                                            class="btn btn-success">
                                                                            <i class="fa-solid fa-square-plus"></i></a>
                                                                    <?php else: ?>
                                                                        <a href="#"
                                                                            wire:click.prevent="separarOrAsignar(<?php echo e($size->pivot->id); ?>)"
                                                                            class="btn btn-secondary disabled">
                                                                            <i class="fa-solid fa-square-plus"></i></a>
                                                                    <?php endif; ?>

                                                                </td>
                                                                
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                          
                                                    

                                                </tbody>
                                            </table>


                                    </ul>
                                </div>
                                

                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<script>
    document.addEventListener("livewire:load", function() {
        Livewire.on("closeModal", function() {
            $("#add-stock-item-<?php echo e($item->id); ?>").modal("hide");
            console.log('se escucho que se quiere cerrar el modal');
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/components/items/add-stock-item.blade.php ENDPATH**/ ?>