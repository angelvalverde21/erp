<div>
    

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        

        <div class="card mt-3">
            <div class="card-header bg bg-secondary">
                <h4>Redes Sociales</h4>
            </div>
            <div class="card-body">

                <div class="row">
                    <div class="col-lg-4 col-12">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fa-brands fa-instagram"></i></span>
                            <input type="text" class="form-control" wire:model.debounce.500ms="options.instagram"
                                placeholder="Instagram" aria-label="Amount (to the nearest dollar)">
                        </div>
                    </div>


                    <div class="col-lg-4 col-12">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fa-brands fa-facebook"></i></span>
                            <input type="text" class="form-control" wire:model.debounce.500ms="options.facebook"
                                placeholder="Facebook" aria-label="Amount (to the nearest dollar)">
                        </div>
                    </div>


                    <div class="col-lg-4 col-12">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fa-brands fa-tiktok"></i></span>
                            <input type="text" class="form-control" wire:model.debounce.500ms="options.tiktok"
                                placeholder="Tiktok" aria-label="Amount (to the nearest dollar)">
                        </div>
                    </div>
                </div>

                
            </div>
            <div class="card-footer">
                <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled"
                    wire.target="save" wire:click.prevent="save()" class="btn btn-success ml-auto"><i
                        class="fa-solid fa-floppy-disk mr-1"></i>
                    Guardar</button>
                
            </div>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        

        <div class="card mt-3">
            <div class="card-header bg bg-secondary">
                <h4>Informacion de la pagina web (Publica)</h4>
            </div>
            <div class="card-body">

                <div class="row">

                    <div class="col-lg-6 col-12">
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fa-solid fa-house"></i></span>
                            <input type="text" class="form-control" wire:model.debounce.500ms="options.title"
                                placeholder="Titulo de la pagina web" aria-label="Username"
                                aria-describedby="basic-addon1">
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fa-solid fa-house"></i></span>
                            <input type="text" class="form-control" wire:model.debounce.500ms="options.iniciales"
                                placeholder="Iniciales, Ejemplo: ARA" aria-label="Iniciales"
                                aria-describedby="basic-addon1">
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fa-solid fa-earth-americas"></i></span>
                            <input type="text" class="form-control" wire:model.debounce.500ms="options.domain"
                                placeholder="dominio" aria-label="Amount (to the nearest dollar)">
                        </div>
                    </div>

                    <div class="col-lg-6 col-6">
                        <div class="input-group mb-3">
                            <span class="input-group-text">S/.</span>
                            <input type="number" class="form-control" wire:model.debounce.500ms="options.ship_min"
                                placeholder="Monto minimo para envio gratis" aria-label="Amount (to the nearest dollar)">
                        </div>
                    </div>

                    <div class="col-lg-6 col-6">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fa-brands fa-whatsapp"></i></span>
                            <input type="number" class="form-control" wire:model.debounce.500ms="options.whatsapp"
                                placeholder="whatsapp" aria-label="Amount (to the nearest dollar)">
                        </div>
                    </div>


                </div>

            </div>
            <div class="card-footer">
                <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled"
                    wire.target="save" wire:click.prevent="save()" class="btn btn-success ml-auto"><i
                        class="fa-solid fa-floppy-disk mr-1"></i>
                    Guardar</button>
                
            </div>
        </div>
        

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header bg bg-secondary">
                        <h4>upload_logo</h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_logo'])->html();
} elseif ($_instance->childHasBeenRendered('upload_logo')) {
    $componentId = $_instance->getRenderedChildComponentId('upload_logo');
    $componentTag = $_instance->getRenderedChildComponentTagName('upload_logo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('upload_logo');
} else {
    $response = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_logo']);
    $html = $response->html();
    $_instance->logRenderedChild('upload_logo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    </div>

                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header bg bg-secondary">
                        <h4>upload_logo_invoice</h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_logo_invoice'])->html();
} elseif ($_instance->childHasBeenRendered('upload_logo_invoice')) {
    $componentId = $_instance->getRenderedChildComponentId('upload_logo_invoice');
    $componentTag = $_instance->getRenderedChildComponentTagName('upload_logo_invoice');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('upload_logo_invoice');
} else {
    $response = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_logo_invoice']);
    $html = $response->html();
    $_instance->logRenderedChild('upload_logo_invoice', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="row">
            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header bg bg-secondary">
                        <h4>Yape</h4>
                    </div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                                    <input type="text" class="form-control"
                                        wire:model.debounce.500ms="options.name_yape" placeholder="Titular Yape"
                                        aria-label="Titular yape">
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="fa-solid fa-mobile-screen"></i></span>
                                    <input type="number" class="form-control"
                                        wire:model.debounce.500ms="options.phone_yape" placeholder="Telefono Yape"
                                        aria-label="Telefono yape">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="fa-solid fa-qrcode"></i></span>
                                    <textarea class="form-control" rows="3" wire:model.debounce.500ms="options.code_yape" placeholder="Codigo Yape (Opcional)"></textarea>
                                </div>
                            </div>
                        </div>

                        <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled"
                            wire.target="save" wire:click.prevent="save()" class="btn btn-success ml-auto mb-3"><i
                                class="fa-solid fa-floppy-disk mr-1"></i>
                            Guardar</button>

                        
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_qr_yape', 'text' => 'Subir Qr Yape'])->html();
} elseif ($_instance->childHasBeenRendered('upload_qr_yape')) {
    $componentId = $_instance->getRenderedChildComponentId('upload_qr_yape');
    $componentTag = $_instance->getRenderedChildComponentTagName('upload_qr_yape');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('upload_qr_yape');
} else {
    $response = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_qr_yape', 'text' => 'Subir Qr Yape']);
    $html = $response->html();
    $_instance->logRenderedChild('upload_qr_yape', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    </div>

                </div>

            </div>

            <div class="col-lg-6">

                <div class="card">
                    <div class="card-header bg bg-secondary">
                        <h4>Plin</h4>
                    </div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                                    <input type="text" class="form-control"
                                        wire:model.debounce.500ms="options.name_plin" placeholder="Titular Plin"
                                        aria-label="Titular Plin">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="fa-solid fa-mobile-screen"></i></span>
                                    <input type="number" class="form-control"
                                        wire:model.debounce.500ms="options.phone_plin" placeholder="Telefono Plin"
                                        aria-label="Telefono Plin">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="input-group mb-3">
                                    <span class="input-group-text"><i class="fa-solid fa-qrcode"></i></span>
                                    <textarea class="form-control" rows="3" wire:model.debounce.500ms="options.code_plin" placeholder="Codigo Plin (Opcional)"></textarea>
                                </div>
                            </div>
                        </div>

                        <button type="button" wire:loading.class="btn-secondary" wire:loading.attr="disabled"
                        wire.target="save" wire:click.prevent="save()" class="btn btn-success ml-auto mb-3"><i
                            class="fa-solid fa-floppy-disk mr-1"></i>
                        Guardar</button>

                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_qr_plin','text' => 'Subir Qr Plin'])->html();
} elseif ($_instance->childHasBeenRendered('upload_qr_plin')) {
    $componentId = $_instance->getRenderedChildComponentId('upload_qr_plin');
    $componentTag = $_instance->getRenderedChildComponentTagName('upload_qr_plin');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('upload_qr_plin');
} else {
    $response = \Livewire\Livewire::mount('components.profile.upload-option', ['store' => $store, 'field' => 'upload_qr_plin','text' => 'Subir Qr Plin']);
    $html = $response->html();
    $_instance->logRenderedChild('upload_qr_plin', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/options/show-options.blade.php ENDPATH**/ ?>