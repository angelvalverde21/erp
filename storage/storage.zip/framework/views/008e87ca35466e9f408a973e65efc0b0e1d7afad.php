<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['wirevalue', 'icon' => '', 'texticon' => '', 'error' => '', 'label' => '', 'wirechange'=>'']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['wirevalue', 'icon' => '', 'texticon' => '', 'error' => '', 'label' => '', 'wirechange'=>'']); ?>
<?php foreach (array_filter((['wirevalue', 'icon' => '', 'texticon' => '', 'error' => '', 'label' => '', 'wirechange'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($label != ''): ?>
    <label for="" class="form-label"><?php echo e($label); ?></label>
<?php endif; ?>

<div class="input-group mb-3">

    <label class="input-group-text">
        <?php if($texticon != ''): ?>
            <?php echo e($texticon); ?>

        <?php else: ?>
            <?php if($icon != ''): ?>
                <i class="<?php echo e($icon); ?>"></i>
            <?php endif; ?>
        <?php endif; ?>
    </label>

    <select class="form-select" wire:model="<?php echo e($wirevalue); ?>" wire:change="<?php echo e($wirechange); ?>">

        <?php echo e($slot); ?>


    </select>

    <?php if($error != ''): ?>
        <?php $__errorArgs = [$wirevalue];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error"><?php echo e($error); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/user/select.blade.php ENDPATH**/ ?>