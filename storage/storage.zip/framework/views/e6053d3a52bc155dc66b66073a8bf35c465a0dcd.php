<div>
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['title' => 'Informacion de pagina web']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Informacion de pagina web']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header p-2">
                    <ul class="nav nav-pills">
                        <li class="nav-item"><a class="nav-link active" href="#carousel" data-toggle="tab">Carousel Web</a></li>
                        <li class="nav-item"><a class="nav-link" href="#carousel-responsive" data-toggle="tab">Carousel Mobile</a></li>
                    </ul>
                </div><!-- /.card-header -->
                <div class="card-body">
                    <div class="tab-content">

                        <!-- /.tab-pane -->
                        <div class="active tab-pane" id="carousel">
                            <!-- The timeline -->
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.profile.card-carousel-home', ['store' => $store] )->html();
} elseif ($_instance->childHasBeenRendered('card-carousel-home')) {
    $componentId = $_instance->getRenderedChildComponentId('card-carousel-home');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-carousel-home');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-carousel-home');
} else {
    $response = \Livewire\Livewire::mount('components.profile.card-carousel-home', ['store' => $store] );
    $html = $response->html();
    $_instance->logRenderedChild('card-carousel-home', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            
                        </div>
                        <!-- /.tab-pane -->
                        
                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="carousel-responsive">
                            <!-- The timeline -->
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.profile.card-carousel-responsive', ['store' => $store] )->html();
} elseif ($_instance->childHasBeenRendered('card-carousel-responsive-home')) {
    $componentId = $_instance->getRenderedChildComponentId('card-carousel-responsive-home');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-carousel-responsive-home');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-carousel-responsive-home');
} else {
    $response = \Livewire\Livewire::mount('components.profile.card-carousel-responsive', ['store' => $store] );
    $html = $response->html();
    $_instance->logRenderedChild('card-carousel-responsive-home', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            
                        </div>
                        <!-- /.tab-pane -->
                        <!-- /.tab-pane -->
                    </div>
                    <!-- /.tab-content -->
                </div><!-- /.card-body -->


            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/profile/show-profile-web.blade.php ENDPATH**/ ?>