<div>

    <?php $__env->startPush('script-header'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['title' => 'Ventas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Ventas']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="card">

            <div class="card-header">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.create-order-modal', ['user' => $orders])->html();
} elseif ($_instance->childHasBeenRendered('create-order-modal')) {
    $componentId = $_instance->getRenderedChildComponentId('create-order-modal');
    $componentTag = $_instance->getRenderedChildComponentTagName('create-order-modal');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('create-order-modal');
} else {
    $response = \Livewire\Livewire::mount('manage.orders.create-order-modal', ['user' => $orders]);
    $html = $response->html();
    $_instance->logRenderedChild('create-order-modal', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>

            <div class="card-body table-responsive">
                

                


                

                <?php if(count($orders) > 0): ?>

                    <table id="example1" class="table table-striped">

                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Cliente</th>
                                <th>Productos</th>
                                <th>Entregar por</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Status</th>
                                <th>Pago</th>
                                <th>Total</th>
                                <th>Autor</th>
                                <th>Creado</th>
                                <th>Actualizado</th>
                                <th>Editar</th>
                            </tr>
                        </thead>
                        
                        <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                

                                <tr <?php if(!$order->is_active): ?> class="bg-danger" <?php endif; ?>>

                                    <td class="text-center" <?php if($order->is_pay()): ?> style="background: #E2FBDF;" <?php endif; ?>>                                            
                                        <a href="<?php echo e(route('manage.orders.edit', [$store->nickname, $order->id])); ?>"
                                        class="btn btn-success mr-2">Editar</a>
                                        <p class="mt-1"><?php echo e($order->id); ?></p>
                                    </td>

                                    <td class="">
                                        <h6><?php echo e(strtoupper($order->buyer->name)); ?></h6>
                                        

                                        <li>DNI: <?php echo e($order->address->dni); ?></li>
                                        <li><?php echo e($order->address->primary); ?></li>
                                        <li><?php echo e($order->address->secondary); ?></li>
                                        <li>References: </li>
                                        <li><?php echo e($order->address->references); ?></li>
                                        <li><?php echo e($order->address->district->name); ?></li>
                                        <li><?php echo e($order->delivery_time_start); ?> Hasta <?php echo e($order->delivery_time_end); ?></li>
                                        <li><?php echo e($order->address->phone); ?></li>

                                    </td>

                                    <td>
                                        

                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(Storage::url($item->content->image)); ?>" data-lightbox="show-images-preview-<?php echo e($order->id); ?>">
                                                <img style="height: 125px" src="<?php echo e(Storage::url($item->content->image)); ?>" alt=""> (<?php echo e($item->content->talla_impresa); ?>)
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                    <td class="text-center">
                                        <?php echo e($order->delivery_man->name); ?>

                                    </td>
                                    <td>

                                        <?php $__currentLoopData = $order->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($status->title); ?>

                                            <?php
                                                break;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </td>
                                    <td>
                                        <?php if($order->is_pay()): ?>
                                            <button class="btn btn-success">Pagado</button>
                                        <?php else: ?>
                                            <button class="btn btn-warning">Pendiente</button>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($order->total_amount); ?></td>

                                    <td><?php echo e($order->total_amount); ?></td>
                                    <td><?php echo e($order->seller->name); ?></td>
                                    <td><?php echo e($order->created_at); ?></td>
                                    <td><?php echo e($order->updated_at); ?></td>
                                    <td>
                                        <a href="#" wire:click="cancelOrder( <?php echo e($order); ?> )"
                                                class="btn btn-danger"><i class="fa-solid fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                <?php else: ?>
                    No hay registros disponibles
                <?php endif; ?>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php $__env->startPush('script-footer'); ?>
        <!-- DataTables  & Plugins -->
        <script src="<?php echo e(asset('admin-lte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/jszip/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin-lte/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

        <script>
            $(function() {
                $("#example1").DataTable({
                    "lengthChange": false,
                    "autoWidth": false,
                    "ordering": false,
                    "buttons": ["pdf", "print"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

            });
        </script>
    <?php $__env->stopPush(); ?>


</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/show-orders-today.blade.php ENDPATH**/ ?>