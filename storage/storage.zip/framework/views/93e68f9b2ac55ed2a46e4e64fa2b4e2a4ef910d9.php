<div>

    

    <?php $__currentLoopData = $color->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="content-info d-flex flex-row">

            <ul style="padding: 0" class="d-flex w-100 justify-content-between align-items-center me-3">
                

                <li class="text-center">
                    <h4><?php echo e($size->name); ?>: </h4>
                </li>

                <li class="text-center">
                    <h4><?php echo e($size->pivot->quantity); ?></h4> 
                    
                </li>

                <li>+</li>

                <li class="text-center"><input type="number" style="width: 75px; margin: 0 auto" placeholder="0"
                        class="form-control" min="1"
                        wire:model.debounce.500ms="inputsAdd.<?php echo e($size->pivot->id); ?>.quantity">
                </li>

                <li>=</li>

                <li class="text-center"><input type="number" style="width: 75px; margin: 0 auto" placeholder="0"
                        class="form-control" min="1"
                        wire:model.debounce.500ms="inputsTotal.<?php echo e($size->pivot->id); ?>.quantity">
                    
                </li>

            </ul>
            <p class="">
                <button class="btn btn-primary" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapseExample-<?php echo e($size->pivot->id); ?>" aria-expanded="false"
                    aria-controls="collapseExample">
                    <i class="fa-solid fa-pen-to-square"></i>
                </button>
            </p>
        </div>

        <div class="collapse" id="collapseExample-<?php echo e($size->pivot->id); ?>">

            <div class="card card-body mb-3">

                <?php if(getStockColorSize($size->pivot->id)->count() > 0): ?>
                    <table class="table">
                        <tr>
                            <td>id</td>
                            <td>observaciones</td>
                            <td></td>
                            <td>creacion</td>
                            <td>eliminar</td>
                        </tr>
                        <?php $__currentLoopData = getStockColorSize($size->pivot->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($stock->id); ?></td>
                                <td></td>
                                <td></td>
                                <td><?php echo e($stock->created_at); ?></td>
                                <td><button class="btn btn-danger" wire:loading.attr="disabled" wire:click="eliminarStock(<?php echo e($stock->id); ?>)"><i class="fa-solid fa-trash"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php else: ?>
                    No hay elementos
                <?php endif; ?>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <button type="button" wire:loading.attr="disabled" wire:click="guardarStock"
        class="btn btn-primary w-100">Guardar</button>

    

    

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product/stock-color-size.blade.php ENDPATH**/ ?>