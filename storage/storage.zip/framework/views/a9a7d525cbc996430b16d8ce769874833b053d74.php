<div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if(!$order->is_active): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="activar d-flex justify-content-center mb-3">
                <button type="button" class="btn btn-success" wire:click="reactivarOrden()"><i
                        class="fa-solid fa-bolt"></i> Reactivar Orden</button>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        
        <?php echo $__env->make('livewire.manage.orders.edit-order._navbar-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="row">

            <div class="col-lg-3"><?php echo $__env->make('livewire.manage.orders.edit-order._navbar-delivery-type', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>

            
            <div class="col-lg-3"><?php echo $__env->make('livewire.manage.orders.edit-order._navbar-collect-methods', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>

            
            <div class="col-lg-3"><?php echo $__env->make('livewire.manage.orders.edit-order._navbar-pay-method', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>

            
            <div class="col-lg-3"><?php echo $__env->make('livewire.manage.orders.edit-order._navbar-delivery-man', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>

        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php echo $__env->make('livewire.manage.orders.edit-order.card-warning-alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


            <div class="row">
                
                <div class="col-12 col-lg-4" x-data="{ shipping_method: 1 }">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.addresses.show-address', ['address' => $order->address_id, 'model_refer' => 'Order', 'model_refer_id' => $order->id])->html();
} elseif ($_instance->childHasBeenRendered('show-address-' . $order->address_id)) {
    $componentId = $_instance->getRenderedChildComponentId('show-address-' . $order->address_id);
    $componentTag = $_instance->getRenderedChildComponentTagName('show-address-' . $order->address_id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('show-address-' . $order->address_id);
} else {
    $response = \Livewire\Livewire::mount('components.addresses.show-address', ['address' => $order->address_id, 'model_refer' => 'Order', 'model_refer_id' => $order->id]);
    $html = $response->html();
    $_instance->logRenderedChild('show-address-' . $order->address_id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>


                <div class="col-12 col-lg-4">

                    

                    <?php if($order->delivery_method_id == 1): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-carrier-details', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-carrier-' . $order->address_id)) {
    $componentId = $_instance->getRenderedChildComponentId('card-carrier-' . $order->address_id);
    $componentTag = $_instance->getRenderedChildComponentTagName('card-carrier-' . $order->address_id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-carrier-' . $order->address_id);
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-carrier-details', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-carrier-' . $order->address_id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endif; ?>
                    
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-date-details', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-details')) {
    $componentId = $_instance->getRenderedChildComponentId('card-details');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-details');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-details');
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-date-details', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-details', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>


                <div class="col-12 col-lg-4">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-shipping-cost', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-carrier-cost-' . $order->address_id)) {
    $componentId = $_instance->getRenderedChildComponentId('card-carrier-cost-' . $order->address_id);
    $componentTag = $_instance->getRenderedChildComponentTagName('card-carrier-cost-' . $order->address_id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-carrier-cost-' . $order->address_id);
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-shipping-cost', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-carrier-cost-' . $order->address_id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>




                
                

            </div>


            <style>
                .table> :not(:first-child) {
                    border-top: 0px solid !important;
                }
            </style>

            

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.items.show-item-all', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-show-all-items')) {
    $componentId = $_instance->getRenderedChildComponentId('card-show-all-items');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-show-all-items');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-show-all-items');
} else {
    $response = \Livewire\Livewire::mount('components.items.show-item-all', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-show-all-items', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


            <div class="row">

                

                <div class="col-12 col-lg-8">
                    <div class="card card-primary card-outline card-outline-tabs">
                        <div class="card-header p-0 border-bottom-0">

                            <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link active" id="comprobatesPago-tab" data-toggle="pill"
                                        href="#comprobatesPago" role="tab" aria-controls="comprobatesPago"
                                        aria-selected="true">Pagos</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" id="comprobantesEmpaque-tab" data-toggle="pill"
                                        href="#comprobantesEmpaque" role="tab" aria-controls="comprobantesEmpaque"
                                        aria-selected="false">Empaque
                                        (<?php echo e($order->comprobantesEmpaque->count()); ?>)</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" id="comprobantesEnvio-tab" data-toggle="pill"
                                        href="#comprobantesEnvio" role="tab" aria-controls="comprobantesEnvio"
                                        aria-selected="false">Envio
                                        (<?php echo e($order->comprobantesEnvio->count()); ?>)</a>
                                </li>

                            </ul>

                        </div>

                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-four-tabContent">

                                <div class="tab-pane fade show active" id="comprobatesPago" role="tabpanel"
                                    aria-labelledby="comprobatesPago-tab">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-show-invoice', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-show-invoice')) {
    $componentId = $_instance->getRenderedChildComponentId('card-show-invoice');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-show-invoice');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-show-invoice');
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-show-invoice', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-show-invoice', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                </div>

                                <div class="tab-pane fade" id="comprobantesEmpaque" role="tabpanel"
                                    aria-labelledby="comprobantesEmpaque-tab">

                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-comprobantes-empaque', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-comprobantes-empaque')) {
    $componentId = $_instance->getRenderedChildComponentId('card-comprobantes-empaque');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-comprobantes-empaque');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-comprobantes-empaque');
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-comprobantes-empaque', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-comprobantes-empaque', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                </div>

                                <div class="tab-pane fade" id="comprobantesEnvio" role="tabpanel"
                                    aria-labelledby="comprobantesEnvio-tab">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-comprobantes-envio', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('card-comprobantes-envio')) {
    $componentId = $_instance->getRenderedChildComponentId('card-comprobantes-envio');
    $componentTag = $_instance->getRenderedChildComponentTagName('card-comprobantes-envio');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('card-comprobantes-envio');
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-comprobantes-envio', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('card-comprobantes-envio', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                </div>

                            </div>
                        </div>
                        <!-- /.card -->
                    </div>

                </div>


                
                <div class="col-lg-4 col">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.orders.edit-order.card-show-summary', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('show-summary')) {
    $componentId = $_instance->getRenderedChildComponentId('show-summary');
    $componentTag = $_instance->getRenderedChildComponentTagName('show-summary');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('show-summary');
} else {
    $response = \Livewire\Livewire::mount('manage.orders.edit-order.card-show-summary', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('show-summary', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

            </div>

            

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    

</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/orders/edit-order.blade.php ENDPATH**/ ?>