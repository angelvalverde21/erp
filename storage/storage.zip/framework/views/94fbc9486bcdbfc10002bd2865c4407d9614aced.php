
<div>
    
    

    <style>
        .dropzone {
            /* height: 100%; */
            border: 2px dotted rgba(0, 0, 0, .3);
        }
    </style>

    <style>
        /* .contenedor{
        display: flex;
        flex-wrap: wrap;
        width: 100%;
        gap: 20px;
    } */

        .contenedor {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(15rem, 1fr));
            /*3 columnas del tamaño de una fraccion*/
            gap: 20px;

        }

        .contenedor .card {
            margin-bottom: 0;
            min-height: 150px;
            position: relative;
        }

        .btn-eliminar-color {
            position: absolute;
            bottom: 10px;
            right: 20px;
        }

        .edit-color {
            position: absolute;
            bottom: 10px;
            left: 20px;
        }

        .btn-color {
            font-size: 15pt;
            color: rgb(44, 44, 44);
        }

        .zoom-color {
            position: relative;
        }

        .drop-zoom {
            position: absolute;
            bottom: 0px;
            width: 100%;

        }

        .drop-zoom form {
            opacity: 0.75;

        }
    </style>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['title' => ''.e($product->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($product->name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="margin-correction mt-3 d-block d-sm-block d-md-none d-lg-none d-xl-none d-xxl-none"></div>

        <div class="row">

            

            <div class="col-lg-12 col-12">
                <div class="row">
                    <div class="col-lg-12 col-12">
                        
                        <div class="card">
                            <div class="card-header py-3">
                                <div class="header-content d-flex justify-content-between align-items-center">
                                    <span>
                                        Publicado en: <?php echo e($product->category->name); ?>

                                    </span>
                                    <a href="<?php echo e(route('manage.products.download.zip', [$store->nickname, $product->id])); ?>"
                                        style="width: 75px;"
                                        class="btn btn-success btn-erp d-flex justify-content-between align-items-center"><i
                                            class="fa-solid fa-download me-2"></i> <span>Stock</span></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <form action="#">
                                    <div class="form-body">

                                        <div class="row">
                                            <div class="col-md-12 p-y-3">
                                                <?php if($store->getOption('domain')): ?>
                                                    <p><a target="_blank"
                                                            href="<?php echo e($store->getOption('domain')); ?>/<?php echo e($product->short_link); ?>"><?php echo e($store->getOption('domain')); ?>/<?php echo e($product->short_link); ?></a>
                                                    </p>
                                                <?php endif; ?>

                                            </div>
                                        </div>

                                        <div class="row p-t-20">
                                            <div class="col-md-12">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'text','wirevalue' => 'product.name','debounce' => '1000','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wirevalue' => 'product.name','debounce' => '1000','error' => 'Este campo es requerido']); ?>
                                                    Titulo
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'hidden','disabled' => 'disabled','wirevalue' => 'product.slug','error' => 'este producto ya existe']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'hidden','disabled' => 'disabled','wirevalue' => 'product.slug','error' => 'este producto ya existe']); ?>
                                                    Url del producto
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>

                                            <style>
                                                .ck-editor__editable_inline {
                                                    min-height: 150px;
                                                }
                                            </style>

                                            <div class="col-md-12">
                                                <label for="">Description</label>
                                                <textarea id="editor" wire:model.defer.debounce.500ms="product.description" wire:ignore.self
                                                    style="height: 150px !important;">
                                                    <?php echo e($product['description']); ?>

                                                </textarea>

                                            </div>

                                        </div>


                                        <div class="row mt-3">
                                            <!--/span-->
                                            <div class="col-md-4">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'number','label' => 'Precio Costo','texticon' => 'S/. ','wirevalue' => 'product.costo','debouce' => '500','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','label' => 'Precio Costo','texticon' => 'S/. ','wirevalue' => 'product.costo','debouce' => '500','error' => 'Este campo es requerido']); ?>
                                                    Precio Costo
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <div class="col-md-4">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'number','label' => 'Precio Normal','texticon' => 'S/. ','wirevalue' => 'product.price','debouce' => '500','error' => 'Este campo es requerido']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','label' => 'Precio Normal','texticon' => 'S/. ','wirevalue' => 'product.price','debouce' => '500','error' => 'Este campo es requerido']); ?>
                                                    Precio Costo
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <div class="col-md-4">
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'number','label' => 'Precio Mayor','texticon' => 'S/. ','wirevalue' => 'product.price_seller','debouce' => '500','error' => 'Debe indicar el precio por mayor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','label' => 'Precio Mayor','texticon' => 'S/. ','wirevalue' => 'product.price_seller','debouce' => '500','error' => 'Debe indicar el precio por mayor']); ?>
                                                    Precio por mayor
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->

                                        <div class="row">
                                            <!--/span-->
                                            <div class="d-flex justify-content-between">

                                                <div class="check">

                                                    <div class="form-check-label" for="flexSwitchCheckDefault">Sobre
                                                        Vender</div>

                                                    <div class="form-check form-switch">
                                                        <input style="width: 75px; height: 25px;"
                                                            class="form-check-input"
                                                            wire:model.debounce.500ms="product.over_sale"
                                                            type="checkbox" role="switch" id="flexSwitchCheckDefault1">

                                                    </div>
                                                </div>

                                                <div class="check">

                                                    <div class="form-check-label" for="flexSwitchCheckDefault">Vender
                                                        como una
                                                        sola talla (ESTANDAR)</div>

                                                    <div class="form-check form-switch d-flex flex-column">
                                                        <input style="width: 75px; height: 25px;"
                                                            class="form-check-input"
                                                            wire:model.debounce.500ms="product.force_size_unique"
                                                            type="checkbox" role="switch" id="flexSwitchCheckDefault2">

                                                    </div>

                                                </div>

                                            </div>


                                            <!--/span-->
                                        </div>
                                        <!--/row-->

                                    </div>
                                </form>
                            </div>
                            <div class="card-footer">

                                <div class="botones d-flex justify-content-between py-2">
                                    <div class="form-actions">
                                        <button type="button" wire:loading.attr="disabled" wire.target="save"
                                            wire:click="save" class="btn btn-success"> <i class="fa fa-check"></i>
                                            Guardar
                                            Cambios</button>
                                        
                                    </div>

                                    <div wire:loading wire:target="save" class="spinner-border" role="status">
                                        <span class="sr-only">Espere...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="col-lg-12 col-12">
                        
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.prices.show-prices', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('show-prices-' . $product->id)) {
    $componentId = $_instance->getRenderedChildComponentId('show-prices-' . $product->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('show-prices-' . $product->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('show-prices-' . $product->id);
} else {
    $response = \Livewire\Livewire::mount('components.prices.show-prices', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('show-prices-' . $product->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        

                        
                        <div class="alert alert-light" role="alert">
                            <ul>
                                <li><?php echo e($product->name); ?></li>
                                <li>Por solo: S/. <?php echo e($product->prices->first()->value); ?></li>
                                <li>Tambien: <?php echo e($product->price_oferta()); ?></li>
                                <li>Envio GRATIS a todo el Peru</li>
                            </ul>

                        </div>
                        

                    </div>
                </div>
            </div>

            <div class="col-lg-12 col-12">

                
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home"
                                    role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span
                                        class="hidden-xs-down">Inventario</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile"
                                    role="tab"><span class="hidden-sm-up"><i class="ti-image"></i></span> <span
                                        class="hidden-xs-down">Fotos</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#messages"
                                    role="tab"><span class="hidden-sm-up"><i class="ti-gallery"></i></span> <span
                                        class="hidden-xs-down">Sessiones (<?php echo e($product->albums->count()); ?>)</span></a>
                            </li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active py-3" id="home" role="tabpanel">
                                
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.products.edit-product.colors', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('product-colors-' . $product->id)) {
    $componentId = $_instance->getRenderedChildComponentId('product-colors-' . $product->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('product-colors-' . $product->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('product-colors-' . $product->id);
} else {
    $response = \Livewire\Livewire::mount('manage.products.edit-product.colors', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('product-colors-' . $product->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                            </div>
                            <div class="tab-pane  py-3" id="profile" role="tabpanel">

                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.products.edit-product.images', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('product-images-' . $product->id)) {
    $componentId = $_instance->getRenderedChildComponentId('product-images-' . $product->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('product-images-' . $product->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('product-images-' . $product->id);
} else {
    $response = \Livewire\Livewire::mount('manage.products.edit-product.images', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('product-images-' . $product->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>

                            <div class="tab-pane py-3" id="messages" role="tabpanel">

                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage.products.edit-product.show-albums', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('product-show-albums-' . $product->id)) {
    $componentId = $_instance->getRenderedChildComponentId('product-show-albums-' . $product->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('product-show-albums-' . $product->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('product-show-albums-' . $product->id);
} else {
    $response = \Livewire\Livewire::mount('manage.products.edit-product.show-albums', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('product-show-albums-' . $product->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>

                        </div>
                    </div>
                </div>
                
            </div>

            


        </div>

        <div class="row">

            <div class="col-lg-7 col">



            </div>

            <div class="col-lg-5 col">


            </div>

        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sectioncontent','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sectioncontent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php $__env->startPush('script'); ?>
        <script>
            ClassicEditor
                .create(document.querySelector('#editor'))
                .then(editor => {
                    editor.model.document.on('change:data', (e) => {
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('product.description', editor.getData());
                    })
                })
                .catch(error => {
                    console.error(error);
                });
        </script>
    <?php $__env->stopPush(); ?>



</div>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/livewire/manage/products/edit-product.blade.php ENDPATH**/ ?>