<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['orderid','store', 'field'=>"", 'wirekey', 'filename', 'iddrop', 'bg'=>'light', 'post'=>'manage.orders.upload']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['orderid','store', 'field'=>"", 'wirekey', 'filename', 'iddrop', 'bg'=>'light', 'post'=>'manage.orders.upload']); ?>
<?php foreach (array_filter((['orderid','store', 'field'=>"", 'wirekey', 'filename', 'iddrop', 'bg'=>'light', 'post'=>'manage.orders.upload']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card border-warning">
    <div class="card-header bg-<?php echo e($bg); ?>"><?php echo e($slot); ?></div>
    <div class="card-body">

        
        <div wire:ignore class="" wire:key="<?php echo e($wirekey); ?>">

            <?php if($field): ?>
            <form method="POST" action="<?php echo e(route( $post , [ 'nickname'=> $store, 'order'=> $orderid, 'field'=> $field ])); ?>" class=" d-flex justify-content-center p-2 dropzone"
                id="<?php echo e($iddrop); ?>">
            <?php else: ?>
            <form method="POST" action="<?php echo e(route( $post , [ 'nickname'=> $store, 'order'=> $orderid ])); ?>" class=" d-flex justify-content-center p-2 dropzone"
                id="<?php echo e($iddrop); ?>">
            <?php endif; ?>

            </form>
        </div>
        <?php if($filename): ?>
            <div class="text-center mt-3" style="100%">
                <img style="height: 150px;" src="<?php echo e(asset('storage/' . $filename)); ?>" alt="">
            </div>
        <?php endif; ?>
    </div>
    
    <?php if($filename): ?>
        <div class="card-footer">
            <a href="#" wire:click.prevent="$emit('deletePhotoOrderJs','<?php echo e($orderid); ?>', '<?php echo e($field); ?>')"
                class="btn btn-danger d-block">Borrar</a>
        </div>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/card-upload-order.blade.php ENDPATH**/ ?>