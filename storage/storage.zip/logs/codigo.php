        $precio_lista = Item::where('order_id',$this->id)->sum(DB::raw('price * quantity'));
        $items = Item::where('order_id',$this->id)->get();

        $subtotal = 0;

        foreach ($items as $item) {
            # code...
            if(isset($item->content->price)){
                $subtotal += ($item->content->price * $item->quantity);
                Log::info('Subtotal del item ' . $item->content->price . ' * ' .$item->quantity. ' : ' . $subtotal);
            }
        }


        Log::info('Subtotal: ' . $subtotal);    

        if($subtotal>0){
            return number_format($subtotal, 2, '.', '');
        }else{
            return number_format($precio_lista, 2, '.', '');
        }